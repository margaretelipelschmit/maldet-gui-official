/* =========================================================================
   Maldet GUI — Frontend Application
   Linux Malware Detect Web Interface
   ========================================================================= */

(function() {
    'use strict';

    // ----- API Helper -----
    var API = {
        base: '/api',
        timeout: 10000,
        _fetch: function(path, options) {
            var self = this;
            options = options || {};
            var method = options.method || 'GET';
            var timeout = options.timeout || self.timeout;
            var retries = options.retries === undefined ? (method === 'GET' ? 2 : 0) : options.retries;
            return new Promise(function(resolve, reject) {
                var xhr = new XMLHttpRequest();
                var retryScheduled = false;
                var timer = setTimeout(function() {
                    retryScheduled = true;
                    xhr.abort();
                    if (method === 'GET' && retries > 0) {
                        setTimeout(function() {
                            self._fetch(path, { method: method, timeout: timeout, retries: retries - 1 })
                                .then(resolve).catch(reject);
                        }, 250);
                    } else {
                        reject(new Error('Request timed out'));
                    }
                }, timeout);
                xhr.open(method, self.base + path, true);
                xhr.setRequestHeader('Accept', 'application/json');
                if (options.body) xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.onreadystatechange = function() {
                    if (xhr.readyState !== 4) return;
                    if (retryScheduled) return;
                    clearTimeout(timer);
                    var data = {};
                    try { data = xhr.responseText ? JSON.parse(xhr.responseText) : {}; }
                    catch (e) { reject(new Error('Invalid server response')); return; }
                    if (xhr.status === 401) {
                        showAuthScreen(data.setup_required);
                        reject(new Error(data.error || 'Authentication required'));
                    } else if (xhr.status >= 200 && xhr.status < 300) resolve(data);
                    else if (xhr.status === 0 && method === 'GET' && retries > 0) {
                        retryScheduled = true;
                        setTimeout(function() {
                            self._fetch(path, { method: method, timeout: timeout, retries: retries - 1 })
                                .then(resolve).catch(reject);
                        }, 250);
                    }
                    else {
                        var error = new Error(data.error || ('Request failed (' + xhr.status + ')'));
                        error.data = data;
                        reject(error);
                    }
                };

                xhr.onerror = function() {
                    clearTimeout(timer);
                    if (retryScheduled) return;
                    if (method === 'GET' && retries > 0) {
                        retryScheduled = true;
                        setTimeout(function() {
                            self._fetch(path, { method: method, timeout: timeout, retries: retries - 1 })
                                .then(resolve).catch(reject);
                        }, 250);
                    } else {
                        reject(new Error('Network error'));
                    }
                };
                xhr.send(options.body || null);
            });
        },
        get: function(path, options) {
            options = options || {};
            options.method = 'GET';
            return this._fetch(path, options);
        },
        post: function(path, body) {
            return this._fetch(path, { method: 'POST', body: JSON.stringify(body || {}) });
        },
        put: function(path, body) {
            return this._fetch(path, { method: 'PUT', body: JSON.stringify(body || {}) });
        },
        del: function(path, body) {
            return this._fetch(path, { method: 'DELETE', body: JSON.stringify(body || {}) });
        }
    };

    function showAuthScreen(setup) {
        var existing = document.getElementById('auth-screen');
        if (existing) return;
        var content = document.getElementById('content');
        if (content) content.innerHTML = '';
        var screen = document.createElement('div');
        screen.id = 'auth-screen';
        screen.className = 'auth-screen';
        screen.innerHTML = '<div class="auth-card"><h1>Maldet GUI</h1><p>' +
            (setup ? 'Defina a senha inicial da WebGUI.' : 'Informe a senha da WebGUI.') +
            '</p><form id="auth-form"><input id="auth-password" type="password" minlength="8" required placeholder="' + tr('Password (minimum 8 characters)') + '">' +
            '<button class="btn btn-primary" type="submit">' + (setup ? 'Definir senha' : 'Entrar') + '</button><p id="auth-error" class="auth-error"></p></form></div>';
        (content || document.body).appendChild(screen);
        screen.querySelector('#auth-form').addEventListener('submit', function(e) {
            e.preventDefault();
            var password = screen.querySelector('#auth-password').value;
            API.post(setup ? '/auth/setup' : '/auth/login', { password: password }).then(function() {
                screen.remove();
                Router.init();
                initStatusIndicator();
            }).catch(function(err) {
                screen.querySelector('#auth-error').textContent = err.message;
            });
        });
    }

    // ----- Toast Notifications -----
    function toast(message, type, duration) {
        type = type || 'info';
        duration = duration || 5000;
        var container = document.getElementById('toast-container');
        if (!container) return;
        var el = document.createElement('div');
        el.className = 'toast toast-' + type;
        el.textContent = message;
        container.appendChild(el);
        setTimeout(function() { if (el.parentNode) el.parentNode.removeChild(el); }, duration);
    }

    // ----- Reboot Countdown -----
    // The backend schedules `shutdown -r +1`, so surface a visible 1-minute
    // regressive timer as soon as the reboot is accepted. The deadline is
    // stored in sessionStorage so a page reload resumes the countdown instead
    // of restarting it from 01:00.
    var REBOOT_DEADLINE_KEY = 'maldet.gui.rebootDeadline';
    var REBOOT_COUNTDOWN_SECONDS = 60;
    // The "Reload WebGUI" button restarts the maldet-gui service after a short
    // delay, so show a matching countdown before the page reconnects.
    var GUI_RELOAD_DEADLINE_KEY = 'maldet.gui.reloadDeadline';
    var GUI_RELOAD_COUNTDOWN_SECONDS = 10;
    var REBOOT_COUNTDOWN_LABELS = {
        id: 'reboot-countdown',
        aria: 'System reboot scheduled',
        icon: '⏻',
        title: 'System reboot scheduled',
        text: 'The server will restart in',
        hint: 'Active scans and connections will be interrupted.'
    };
    var RELOAD_COUNTDOWN_LABELS = {
        id: 'reload-countdown',
        aria: 'WebGUI restart scheduled',
        icon: '🔃',
        title: 'WebGUI restart scheduled',
        text: 'The WebGUI will restart in',
        hint: 'The page reconnects automatically when the service is back.'
    };
    // After the countdown reaches zero the service goes down. Instead of
    // guessing how long that takes, poll the public health endpoint until the
    // WebGUI answers again and then refresh the page automatically.
    var REBOOT_POLL_INTERVAL_SECONDS = 5;
    var REBOOT_POLL_GRACE_SECONDS = 20;   // let the host go down before trusting a first "up"
    var REBOOT_POLL_MAX_SECONDS = 600;    // stop probing after 10 minutes without success
    var REBOOT_POLL_TIMEOUT_MS = 3000;    // per-request timeout for the health probe
    var _rebootCountdownOverlay = null;
    var _rebootCountdownTimerEl = null;
    var _rebootCountdownTextEl = null;
    var _rebootCountdownInterval = null;
    var _rebootCountdownDeadline = 0;
    var _countdownLabels = null;
    var _countdownStorageKey = REBOOT_DEADLINE_KEY;
    var _rebootPollTimer = null;
    var _rebootPollStartedAt = 0;
    var _rebootPollSawDown = false;

    function readCountdownDeadline(key) {
        try {
            return parseInt(sessionStorage.getItem(key), 10) || 0;
        } catch (e) {
            return 0;
        }
    }
    function writeCountdownDeadline(key, deadline) {
        try { sessionStorage.setItem(key, String(deadline)); } catch (e) {}
    }
    function clearCountdownDeadline(key) {
        try { sessionStorage.removeItem(key); } catch (e) {}
    }
    function formatRebootCountdown(totalSeconds) {
        totalSeconds = Math.max(0, Math.floor(totalSeconds));
        var minutes = Math.floor(totalSeconds / 60);
        var seconds = totalSeconds % 60;
        return (minutes < 10 ? '0' : '') + minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
    }
    function renderCountdownOverlay(labels) {
        // Only one countdown is ever shown at a time; if a different one is on
        // screen, replace it before building this one.
        if (_rebootCountdownOverlay && _countdownLabels === labels) return;
        if (_rebootCountdownOverlay) {
            var previous = _rebootCountdownOverlay.parentNode;
            if (previous && previous.removeChild) previous.removeChild(_rebootCountdownOverlay);
        }
        _countdownLabels = labels;
        var overlay = document.createElement('div');
        overlay.id = labels.id;
        overlay.className = 'reboot-countdown-overlay';
        overlay.setAttribute('role', 'alertdialog');
        overlay.setAttribute('aria-live', 'assertive');
        overlay.setAttribute('aria-label', tr(labels.aria));
        var card = document.createElement('div');
        card.className = 'reboot-countdown-card';
        var icon = document.createElement('div');
        icon.className = 'reboot-countdown-icon';
        icon.textContent = labels.icon;
        var title = document.createElement('div');
        title.className = 'reboot-countdown-title';
        title.textContent = tr(labels.title);
        var text = document.createElement('div');
        text.className = 'reboot-countdown-text';
        text.textContent = tr(labels.text);
        var timer = document.createElement('div');
        timer.className = 'reboot-countdown-timer';
        timer.id = 'reboot-countdown-timer';
        timer.setAttribute('role', 'timer');
        var hint = document.createElement('div');
        hint.className = 'reboot-countdown-hint';
        hint.textContent = tr(labels.hint);
        card.appendChild(icon);
        card.appendChild(title);
        card.appendChild(text);
        card.appendChild(timer);
        card.appendChild(hint);
        overlay.appendChild(card);
        (document.body || document.documentElement).appendChild(overlay);
        _rebootCountdownOverlay = overlay;
        _rebootCountdownTimerEl = timer;
        _rebootCountdownTextEl = text;
    }
    function updateRebootCountdown() {
        if (!_rebootCountdownTimerEl) return;
        var remaining = Math.max(0, Math.ceil((_rebootCountdownDeadline - Date.now()) / 1000));
        _rebootCountdownTimerEl.textContent = formatRebootCountdown(remaining);
        if (remaining <= 0) {
            if (_rebootCountdownTextEl) _rebootCountdownTextEl.textContent = tr('Restarting now...');
            clearCountdownDeadline(_countdownStorageKey);
            if (_rebootCountdownInterval) {
                clearInterval(_rebootCountdownInterval);
                _rebootCountdownInterval = null;
            }
            scheduleRebootReloadPoll();
        }
    }
    // The timer hit zero and the host is going down for a reboot. Poll the
    // public /api/auth/status endpoint until the WebGUI answers again, then
    // refresh the page so the browser reconnects on its own instead of leaving
    // a dead page open.
    function scheduleRebootReloadPoll() {
        if (_rebootPollTimer) return;
        _rebootPollStartedAt = Date.now();
        _rebootPollSawDown = false;
        _rebootPollTimer = setInterval(pollRebootServer, REBOOT_POLL_INTERVAL_SECONDS * 1000);
    }
    function stopRebootReloadPoll() {
        if (!_rebootPollTimer) return;
        clearInterval(_rebootPollTimer);
        _rebootPollTimer = null;
    }
    // Lightweight reachability probe to the public health endpoint. Kept separate
    // from API._fetch so it never triggers the auth screen or the GET retry
    // backoff while the host is rebooting.
    function probeRebootServer(callback) {
        var xhr;
        try {
            xhr = new XMLHttpRequest();
        } catch (e) {
            callback(false);
            return;
        }
        var settled = false;
        var finish = function(up) {
            if (settled) return;
            settled = true;
            clearTimeout(timer);
            callback(up);
        };
        var timer = setTimeout(function() {
            try { xhr.abort(); } catch (e) {}
            finish(false);
        }, REBOOT_POLL_TIMEOUT_MS);
        xhr.open('GET', API.base + '/auth/status', true);
        xhr.setRequestHeader('Accept', 'application/json');
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== 4) return;
            finish(xhr.status === 200);
        };
        xhr.onerror = function() { finish(false); };
        xhr.send();
    }
    function pollRebootServer() {
        probeRebootServer(function(up) {
            var elapsed = Date.now() - _rebootPollStartedAt;
            // Only trust an "up" answer once the host has actually gone down, or
            // after the grace window in case the reboot finished faster than our
            // first probe.
            if (up && (_rebootPollSawDown || elapsed >= REBOOT_POLL_GRACE_SECONDS * 1000)) {
                stopRebootReloadPoll();
                window.location.reload();
                return;
            }
            if (!up) _rebootPollSawDown = true;
            if (elapsed >= REBOOT_POLL_MAX_SECONDS * 1000) stopRebootReloadPoll();
        });
    }
    function beginCountdown(deadline, labels, storageKey) {
        _rebootCountdownDeadline = deadline;
        _countdownStorageKey = storageKey;
        writeCountdownDeadline(storageKey, deadline);
        renderCountdownOverlay(labels);
        if (_rebootCountdownInterval) clearInterval(_rebootCountdownInterval);
        _rebootCountdownInterval = setInterval(updateRebootCountdown, 1000);
        updateRebootCountdown();
    }
    function startCountdown(totalSeconds, labels, storageKey) {
        beginCountdown(Date.now() + totalSeconds * 1000, labels, storageKey);
    }
    function resumeCountdown(labels, storageKey) {
        var deadline = readCountdownDeadline(storageKey);
        if (!deadline) return;
        if (deadline - Date.now() <= 0) { clearCountdownDeadline(storageKey); return; }
        beginCountdown(deadline, labels, storageKey);
    }
    function startRebootCountdown(totalSeconds) {
        startCountdown(totalSeconds || REBOOT_COUNTDOWN_SECONDS,
            REBOOT_COUNTDOWN_LABELS, REBOOT_DEADLINE_KEY);
    }
    function resumeRebootCountdown() {
        resumeCountdown(REBOOT_COUNTDOWN_LABELS, REBOOT_DEADLINE_KEY);
    }
    function startGuiReloadCountdown(totalSeconds) {
        startCountdown(totalSeconds || GUI_RELOAD_COUNTDOWN_SECONDS,
            RELOAD_COUNTDOWN_LABELS, GUI_RELOAD_DEADLINE_KEY);
    }
    function resumeGuiReloadCountdown() {
        resumeCountdown(RELOAD_COUNTDOWN_LABELS, GUI_RELOAD_DEADLINE_KEY);
    }
    function initRebootButton() {
        var rebootBtn = document.getElementById('system-reboot-btn');
        if (!rebootBtn) return;
        rebootBtn.addEventListener('click', function() {
            if (!confirm(tr('Reboot the entire server in one minute? Active scans and connections will be interrupted.'))) return;
            rebootBtn.disabled = true;
            API.post('/system/reboot', {}).then(function() {
                rebootBtn.disabled = false;
                // The host reboots in one minute; show the regressive timer.
                startRebootCountdown(REBOOT_COUNTDOWN_SECONDS);
            }).catch(function(e) {
                rebootBtn.disabled = false;
                toast('Error: ' + e.message, 'error');
            });
        });
    }
    function initReloadGuiButton() {
        var reloadBtn = document.getElementById('reload-gui-btn');
        if (!reloadBtn) return;
        reloadBtn.addEventListener('click', function() {
            // Restart the maldet-gui backend service (fresh code/assets) after a
            // short delay, then let the countdown reconnect the page.
            if (!confirm(tr('Restart the WebGUI service in 10 seconds? The page will reconnect automatically.'))) return;
            reloadBtn.disabled = true;
            API.post('/system/reload', {}).then(function() {
                reloadBtn.disabled = false;
                startGuiReloadCountdown(GUI_RELOAD_COUNTDOWN_SECONDS);
            }).catch(function(e) {
                reloadBtn.disabled = false;
                toast('Error: ' + e.message, 'error');
            });
        });
    }

    // ----- Format Helpers -----
    function fmtTime(epoch) {
        if (!epoch || epoch === 0) return 'n/a';
        return new Date(epoch * 1000).toLocaleString();
    }
    function fmtSize(bytes) {
        if (!bytes || bytes === 0) return '0 B';
        var k = 1024, units = ['B', 'KB', 'MB', 'GB', 'TB'];
        var i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + units[i];
    }
    function fmtDuration(seconds) {
        if (!seconds || seconds === 0) return 'n/a';
        seconds = parseInt(seconds);
        var d = Math.floor(seconds / 86400);
        var h = Math.floor((seconds % 86400) / 3600);
        var m = Math.floor((seconds % 3600) / 60);
        var s = seconds % 60;
        if (d > 0) return d + 'd ' + h + 'h ' + m + 'm';
        if (h > 0) return h + 'h ' + m + 'm ' + s + 's';
        if (m > 0) return m + 'm ' + s + 's';
        return s + 's';
    }
    function escapeHtml(str) {
        if (str === null || str === undefined) return '';
        var div = document.createElement('div');
        div.textContent = String(str);
        return div.innerHTML;
    }

    // ----- UI language -----
    var I18N = {
        lang: localStorage.getItem('maldet.gui.language') || 'en',
        pt: {
            'Language': 'Idioma', 'English': 'Inglês', 'Português (Brasil)': 'Português (Brasil)',
            'Dashboard': 'Painel', 'Scanner': 'Scanner', 'Scan Management': 'Gerenciamento de scans',
            'About Maldet': 'Sobre o Maldet',
            'Quarantine': 'Quarentena', 'Reports': 'Relatórios', 'Monitoring': 'Monitoramento',
            'Updates': 'Atualizações', 'Configuration': 'Configuração', 'Test Alerts': 'Testar alertas',
            'Logs': 'Logs', 'Event Log': 'Log de eventos', 'Ignore Lists': 'Listas de exclusão', 'Maintenance': 'Manutenção',
            'System Info': 'Informações do sistema', 'Checking...': 'Verificando...',
            'Offline': 'Offline', 'maldet not found': 'maldet não encontrado',
            'Online · Monitor ON': 'Online · Monitor ligado', 'Online · Monitor OFF': 'Online · Monitor desligado',
            'Loading...': 'Carregando...', 'Error': 'Erro', 'System Information': 'Informações do sistema',
            'Binary Detection': 'Detecção de binários', 'Scan Configuration': 'Configuração do scan',
            'Scan Type': 'Tipo de scan', 'Scanner engine': 'Mecanismo do scanner', 'Path': 'Caminho',
            'Browse': 'Procurar', 'Modified within (days)': 'Modificados nos últimos (dias)',
            'Config Overrides (-co)': 'Substituições de configuração (-co)', 'Include Regex (-i)': 'Regex de inclusão (-i)',
            'Exclude Regex (-x)': 'Regex de exclusão (-x)', 'Options': 'Opções',
            'Run in background (recommended)': 'Executar em segundo plano (recomendado)',
            'Start Scan': 'Iniciar scan', 'Preparing...': 'Preparando...', 'Starting...': 'Iniciando...',
            'Choose scan folder': 'Escolher pasta do scan', 'Cancel': 'Cancelar',
            'Select this folder': 'Selecionar esta pasta', 'Active Scans': 'Scans ativos',
            'Live updates every 3s': 'Atualização ao vivo a cada 3 s',
            'Live updates every 5s': 'Atualização ao vivo a cada 5 s', 'Details': 'Detalhes',
            'Stop': 'Parar', 'Stopping...': 'Parando...', 'Close': 'Fechar',
            'Quarantined Files': 'Arquivos em quarentena', 'Scan Reports': 'Relatórios de scans',
            'Quarantine': 'Quarentenar', 'Restore': 'Restaurar', 'Inotify Monitoring': 'Monitoramento inotify',
            'Start': 'Iniciar', 'Reload': 'Recarregar', 'Update': 'Atualizar', 'Beta': 'Beta',
            'Update Sigs': 'Atualizar assinaturas', 'Update ClamAV': 'Atualizar ClamAV',
            'Save Changes': 'Salvar alterações',
            'File': 'Arquivo',
            'Edit values below and save only the settings you changed. Click the tip icon (i) next to a field for details.':
                'Edite os valores abaixo e salve apenas as configurações alteradas. Clique no ícone de dica (i) ao lado de um campo para mais detalhes.',
            'Search settings...': 'Pesquisar configurações...',
            'Expand all': 'Expandir tudo', 'Collapse all': 'Recolher tudo',
            'Show tip': 'Exibir dica', 'No changes': 'Sem alterações',
            'unsaved change(s)': 'alteração(ões) não salva(s)',
            'E-mail': 'E-mail', 'Telegram': 'Telegram',
            'General Options': 'Opções gerais', 'SCAN OPTIONS': 'Opções de scan',
            'QUARANTINE OPTIONS': 'Opções de quarentena', 'MONITORING OPTIONS': 'Opções de monitoramento',
            'STATISTICAL ELK COLLECT': 'Coleta estatística ELK', 'SESSION FORMAT': 'Formato de sessão',
            'STATISTICAL ANALYSIS': 'Análise estatística', 'SCAN PROGRESS LOGGING': 'Registro de progresso do scan',
            'POST-SCAN HOOKS': 'Hooks pós-scan',
            'Schedules': 'Agendamentos',
            'Scheduled Scans': 'Scans agendados',
            'New Schedule': 'Novo agendamento',
            'Edit Schedule': 'Editar agendamento',
            'Cron Jobs': 'Tarefas cron',
            'System-managed cron jobs installed by the installer (read-only). GUI-managed schedules are listed separately below.':
                'Tarefas cron do sistema instaladas pelo instalador (somente leitura). Os agendamentos gerenciados pela GUI estão listados separadamente abaixo.',
            'View raw file': 'Ver arquivo bruto',
            'Hide raw file': 'Ocultar arquivo bruto',
            'File not installed': 'Arquivo não instalado',
            'No scheduled scans yet. Click "New Schedule" to create one.': 'Nenhum scan agendado ainda. Clique em "Novo agendamento" para criar um.',
            'Name': 'Nome', 'Path': 'Caminho', 'Schedule': 'Frequência', 'Status': 'Status',
            'Enabled': 'Habilitado', 'Disabled': 'Desabilitado',
            'Edit': 'Editar', 'Delete': 'Excluir', 'Enable': 'Habilitar', 'Disable': 'Desabilitar',
            'View Reports': 'Ver relatórios', 'Reports for': 'Relatórios de',
            'No reports found yet for this schedule.': 'Nenhum relatório encontrado ainda para este agendamento.',
            'Delete this schedule? Its cron entry will be removed.': 'Excluir este agendamento? A entrada do cron será removida.',
            'Schedule saved': 'Agendamento salvo', 'Schedule deleted': 'Agendamento excluído',
            'Schedule name': 'Nome do agendamento', 'Scan type': 'Tipo de scan',
            'Full scan (all files)': 'Scan completo (todos os arquivos)',
            'Recent files only': 'Somente arquivos recentes',
            'Modified within (days)': 'Modificados nos últimos (dias)',
            'Frequency': 'Frequência', 'Daily': 'Diário', 'Weekly': 'Semanal', 'Custom (cron expression)': 'Personalizado (expressão cron)',
            'Time': 'Horário', 'Hour': 'Hora', 'Minute': 'Minuto', 'Day of week': 'Dia da semana',
            'Sunday': 'Domingo', 'Monday': 'Segunda-feira', 'Tuesday': 'Terça-feira', 'Wednesday': 'Quarta-feira',
            'Thursday': 'Quinta-feira', 'Friday': 'Sexta-feira', 'Saturday': 'Sábado',
            'Custom cron expression': 'Expressão cron personalizada',
            '5 fields: minute hour day month weekday (e.g. "0 3 * * *")': '5 campos: minuto hora dia mês dia-da-semana (ex.: "0 3 * * *")',
            'Enabled (schedule will run)': 'Habilitado (o agendamento será executado)',
            'Save Schedule': 'Salvar agendamento', 'Saving...': 'Salvando...',
            'Daily at': 'Diariamente às', 'Weekly on': 'Semanalmente em', 'at': 'às',
            'Custom:': 'Personalizado:',
            'Daily scan & maintenance': 'Scan diário e manutenção',
            'Weekly signature watchdog': 'Verificação semanal de assinaturas',
            'Public path scan trigger': 'Gatilho de scan de caminhos públicos',
            'Independent signature updates': 'Atualizações independentes de assinaturas',
            'GUI-managed scheduled scans': 'Scans agendados gerenciados pela GUI',            'Save ignore list': 'Salvar lista de exclusão',
            'Ignore list saved': 'Lista de exclusão salva',
            'Ignore list save failed: ': 'Falha ao salvar a lista de exclusão: ',
            'Test Alerts': 'Testar alertas', 'Type': 'Tipo', 'Channel': 'Canal',
            'Send Test Alert': 'Enviar alerta de teste', 'Event Log': 'Log de eventos',
            'entries': 'entradas', 'Maintenance': 'Manutenção', 'Run Maintenance': 'Executar manutenção',
            'Purge All Data': 'Apagar todos os dados', 'Maldet Version': 'Versão do Maldet',
            'Signature Set': 'Conjunto de assinaturas', 'Monitor': 'Monitor',
            'ONLINE': 'ATIVO', 'OFFLINE': 'INATIVO', 'Maldet native (live file progress)': 'Maldet nativo (progresso em tempo real)',
            'ClamAV/clamdscan (faster, limited progress)': 'ClamAV/clamdscan (mais rápido, progresso limitado)',
            'ClamAV updated': 'Base de dados do ClamAV atualizada',
            'ClamAV already current': 'A base de dados do ClamAV já está atualizada',
            'ClamAV update failed: ': 'Falha ao atualizar o ClamAV: ',
            'Update complete: already current': 'Atualização concluída: o Maldet já está na versão mais recente',
            'Update complete: version changed': 'Atualização concluída: nova versão do Maldet instalada',
            'Update failed: ': 'Falha na atualização: ',
            'Signatures updated': 'Assinaturas atualizadas com sucesso',
            'Signatures already current': 'As assinaturas já estão atualizadas',
            'Signature update failed: ': 'Falha ao atualizar as assinaturas: ',
            'see the update details below': 'veja os detalhes da atualização abaixo',
            'LMD Version': 'Versão do LMD', 'Signatures': 'Assinaturas',
            'Installer location': 'Local do instalador',
            'Not available in the installed runtime': 'Não disponível na instalação atual',
            'update:unknown': 'desconhecido', 'update:missing': 'ausente', 'update:available': 'disponível',
            'update:completed': 'concluída', 'update:failed': 'falhou', 'update:yes': 'sim', 'update:no': 'não',
            'update:Update': 'Atualização',
            'update:signature update': 'Atualização de assinaturas',
            'update:version update': 'Atualização de versão',
            'update:beta version update': 'Atualização para a versão beta',
            'update:clamav database update': 'Atualização da base de dados do ClamAV',
            'Ready to run': 'Pronto para executar', 'Scan complete - hits found!': 'Scan concluído — ameaças encontradas!',
            'Scan complete - no malware': 'Scan concluído — nenhum malware encontrado',
            'Scan started in background': 'Scan iniciado em segundo plano', 'Monitor started': 'Monitor iniciado',
            'Monitor stopped': 'Monitor parado', 'Monitor reloaded': 'Monitor recarregado',
            'Real-time monitoring (inotify)': 'Monitoramento em tempo real (inotify)',
            'Inotify': 'inotify',
            'Monitoring status': 'Status do monitoramento', 'RUNNING': 'ATIVO', 'STOPPED': 'PARADO',
            'Warning:': 'Aviso:', 'the GUI is not running with root privileges.': 'a GUI não está executando com privilégios de root.',
            'Inotify monitoring usually requires root (the maldet config and state directories are root-only).':
                'O monitoramento inotify geralmente requer root (a configuração e os diretórios de estado do maldet são exclusivos do root).',
            'Start the GUI as root to enable the monitor.': 'Inicie a GUI como root para habilitar o monitor.',
            'Start': 'Iniciar', 'Stop': 'Parar', 'Reload': 'Recarregar',
            'Users monitored': 'Usuários monitorados',
            'Select the users whose home directories should be monitored. Changes take effect after Reload.':
                'Selecione os usuários cujos diretórios home serão monitorados. As alterações entram em vigor após Recarregar.',
            'Save user selection': 'Salvar seleção de usuários',
            'User directory scope': 'Escopo dos diretórios dos usuários',
            'Only public_html and htdocs of each user': 'Apenas public_html e htdocs de cada usuário',
            'All folders of each user (recursive)': 'Todas as pastas de cada usuário (recursivo)',
            'Other paths configured manually': 'Outros caminhos configurados manualmente',
            'In webroot-only mode, additional document roots and temporary folders are not watched. Reload to apply changes.':
                'No modo apenas diretórios web, document roots adicionais e pastas temporárias não são monitorados. Recarregue para aplicar.',
            'Changes take effect after Reload.': 'As alterações entram em vigor após Recarregar.',
            'Save monitoring scope': 'Salvar escopo do monitoramento',
            'Monitor scope saved': 'Escopo do monitoramento salvo',
            'No eligible home users found.': 'Nenhum usuário elegível em /home foi encontrado.',
            'Web server detection': 'Detecção de servidor web',
            'Web server detection is unavailable.': 'A detecção de servidor web está indisponível.',
            'No running web server detected.': 'Nenhum servidor web em execução foi detectado.',
            'Email folder detection': 'Detecção de pastas de e-mail',
            'Email folder detection is unavailable.': 'A detecção de pastas de e-mail está indisponível.',
            'No running mail server detected.': 'Nenhum servidor de e-mail em execução foi detectado.',
            'Detected mail server:': 'Servidor de e-mail detectado:',
            'Email folders detected:': 'Pastas de e-mail detectadas:',
            'No email folders found on this host.': 'Nenhuma pasta de e-mail encontrada neste host.',
            'Monitor detected email folders (e.g. /var/mail, /var/vmail)':
                'Monitorar pastas de e-mail detectadas (ex.: /var/mail, /var/vmail)',
            'Email folder monitoring updated': 'Monitoramento de pastas de e-mail atualizado',
            'maildirs': 'pastas de e-mail',
            'Detected web server:': 'Servidor web detectado:',
            'Document roots detected:': 'Document roots detectados:',
            'No document roots found in the server configuration.': 'Nenhum document root encontrado na configuração do servidor.',
            'Monitor detected document roots (e.g. public_html)': 'Monitorar document roots detectados (ex.: public_html)',
            'Changes take effect after Reload or restarting the monitor.': 'As alterações entram em vigor após Recarregar ou reiniciar o monitor.',
            'Save': 'Salvar',
            'public_html': 'public_html',
            'Monitoring of detected document roots (e.g. public_html) enabled': 'Monitoramento dos document roots detectados (ex.: public_html) habilitado',
            'Monitoring of detected document roots (e.g. public_html) disabled': 'Monitoramento dos document roots detectados (ex.: public_html) desabilitado',
            'Web server monitoring updated': 'Monitoramento do servidor web atualizado',
            'Monitored folders': 'Pastas monitoradas',
            'Choose folder': 'Escolher pasta',
            'Add folder': 'Adicionar pasta',
            'Save folders': 'Salvar pastas',
            'Remove': 'Remover',
            'Folder path (e.g. /var/www/html)': 'Caminho da pasta (ex.: /var/www/html)',
            'These folders are added to the monitored paths (monitor_paths.extra). Absolute paths must exist on the server. Changes take effect after Reload.':
                'Estas pastas são adicionadas aos caminhos monitorados (monitor_paths.extra). Os caminhos absolutos precisam existir no servidor. As alterações entram em vigor após Recarregar.',
            'No extra folders configured. Use the field above to add folders to real-time monitoring.':
                'Nenhuma pasta extra configurada. Use o campo acima para adicionar pastas ao monitoramento em tempo real.',
            'Enter a folder path to add.': 'Informe um caminho de pasta para adicionar.',
            'Absolute path required (e.g. /var/www).': 'É necessário um caminho absoluto (ex.: /var/www).',
            'Folder already in the list.': 'A pasta já está na lista.',
            'Monitored folders saved': 'Pastas monitoradas salvas',
            'Quarantined Files': 'Arquivos em quarentena',
            'No files in quarantine.': 'Nenhum arquivo em quarentena.',
            'Details': 'Detalhes',
            'Restore': 'Restaurar',
            'Restore all': 'Restaurar tudo',
            'Restore all quarantined files?': 'Restaurar todos os arquivos em quarentena?',
            'Clean': 'Limpar',
            'Delete': 'Excluir',
            'File restored successfully': 'Arquivo restaurado com sucesso',
            'Quarantined file deleted': 'Arquivo em quarentena excluído',
            'File cleaned successfully (restored to original path)': 'Arquivo limpo com sucesso (restaurado ao caminho original)',
            'All quarantined files restored': 'Todos os arquivos em quarentena foram restaurados',
            'Try to clean': 'Tentar limpar',
            'Permanently delete': 'Excluir permanentemente',
            'from quarantine?': 'da quarentena?',
            'This cannot be undone — the file will NOT be restored.': 'Esta ação não pode ser desfeita — o arquivo NÃO será restaurado.',
            'The file is restored to its original location, cleaned with the matching maldet clean rule and rescanned. If cleaning fails, it is moved back to quarantine.':
                'O arquivo é restaurado ao local original, limpo com a regra de limpeza correspondente do maldet e reescaneado. Se a limpeza falhar, ele volta para a quarentena.',
            'Monitor activity': 'Atividade do monitor',
            'Live': 'Ao vivo',
            'Files detected by inotify (create/move/modify) in real time, newest first. These are queued for the monitor scan batches.':
                'Arquivos detectados pelo inotify (criação/movimentação/modificação) em tempo real, mais recentes primeiro. Eles entram na fila dos lotes de scan do monitor.',
            'No monitored file activity yet. New, moved or modified files will appear here as the monitor detects them.':
                'Nenhuma atividade de arquivos monitorados ainda. Arquivos novos, movidos ou modificados aparecerão aqui conforme o monitor os detectar.',
            'Monitor is stopped — no live activity. Start the monitor to watch files in real time.':
                'O monitor está parado — sem atividade em tempo real. Inicie o monitor para acompanhar arquivos em tempo real.',
            'events logged': 'eventos registrados',
            'Enabled': 'Habilitado', 'Disabled': 'Desabilitado',
            'Security': 'Segurança',
            'Change the WebGUI password. Password must contain at least 8 characters.':
                'Altere a senha da WebGUI. A senha deve ter no mínimo 8 caracteres.',
            'Current password': 'Senha atual',
            'New password': 'Nova senha',
            'Confirm password': 'Confirmar senha',
            'Change password': 'Alterar senha',
            'Please fill in all password fields.': 'Preencha todos os campos de senha.',
            'New password must contain at least 8 characters.': 'A nova senha deve ter no mínimo 8 caracteres.',
            'New passwords do not match.': 'As novas senhas não coincidem.',
            'Password changed successfully.': 'Senha alterada com sucesso.',
            'Password change failed: ': 'Falha ao alterar a senha: ',
            'Refresh': 'Atualizar', 'Settings': 'Configurações',
            'maldet not found': 'maldet não encontrado',
            'System Information': 'Informações do sistema', 'CPU': 'CPU',
            'cores': 'núcleos', 'ClamAV Status': 'Status do ClamAV',
            'Maldet Version': 'Versão do Maldet', 'Signature Set': 'Conjunto de assinaturas',
            'Binary Detection': 'Detecção de binários', 'not found': 'não encontrado',
            'Installation directory:': 'Diretório de instalação:',
            'Installer directory:': 'Diretório do instalador:',
            'Installer:': 'Instalador:', 'Update details': 'Detalhes da atualização',
            'Status:': 'Status:', 'Operation:': 'Operação:', 'Before:': 'Antes:',
            'After:': 'Depois:', 'Changed:': 'Alterado:', 'Command output': 'Saída do comando',
            'No output returned by maldet.': 'O maldet não retornou saída.',
            'Scan Configuration': 'Configuração do scan', 'Choose a folder or enter an absolute directory path manually.':
                'Escolha uma pasta ou informe manualmente um caminho absoluto.',
            'Scans files changed within the selected number of days.':
                'Escaneia arquivos alterados dentro do número de dias selecionado.',
            'Choose scan folder': 'Escolher pasta do scan', 'Loading folders...': 'Carregando pastas...',
            'No subfolders found.': 'Nenhuma subpasta encontrada.',
            'Cannot read this directory: ': 'Não foi possível ler este diretório: ',
            'Scan details': 'Detalhes do scan', 'Infection details': 'Detalhes da infecção',
            'Scan report': 'Relatório do scan', 'Error loading details: ': 'Erro ao carregar detalhes: ',
            'Error loading report: ': 'Erro ao carregar relatório: ',
            'Show Report': 'Exibir relatório',
            'Scan ID': 'ID do scan', 'Path': 'Caminho', 'Started': 'Iniciado',
            'Completed': 'Concluído', 'Duration': 'Duração', 'Files': 'Arquivos',
            'Hits': 'Detecções', 'Quarantined': 'Em quarentena', 'Actions': 'Ações',
            'No completed reports found.': 'Nenhum relatório concluído encontrado.',
            'scan(s) still active.': 'scan(s) ainda ativo(s).',
            'scan(s) stopped and resumable.': 'scan(s) parado(s) e retomável(is).',
            'Stopped': 'Parado', 'Resume': 'Retomar', 'Discard': 'Descartar',
            'Resuming...': 'Retomando...', 'Discarding...': 'Descartando...',
            'Resource Usage': 'Uso de recursos', 'RAM': 'RAM',
            'Waiting for data...': 'Aguardando dados...', 'Live': 'Ao vivo',
            'Host overview': 'Visão geral do host', 'System resources': 'Recursos do sistema',
            'Disk': 'Disco', 'Unavailable': 'Indisponível', 'used': 'usados',
            'free': 'livres', 'available': 'disponíveis', 'of': 'de',
            'Host and runtime': 'Host e ambiente', 'Hostname': 'Nome do host',
            'Operating system': 'Sistema operacional', 'Architecture': 'Arquitetura',
            'Processor': 'Processador', 'Python version': 'Versão do Python',
            'CPU cores': 'Núcleos de CPU', 'Install path': 'Caminho de instalação',
            'Log directory': 'Diretório de logs', 'Maldet binary': 'Binário do Maldet',
            'ClamAV': 'ClamAV', 'Available': 'Disponível', 'Missing': 'Ausente',
            'Found': 'Encontrado', 'No binaries reported': 'Nenhum binário informado',
            'Installer path': 'Caminho do instalador', 'GUI privileges': 'Privilégios da GUI',
            'Root': 'Root', 'Unprivileged': 'Sem privilégios',
            'Installer directory': 'Diretório do instalador',
            'Effective UID': 'UID efetivo', 'Monitor PIDs': 'PIDs do monitor',
            'Reboot system': 'Reiniciar sistema', 'Reboot': 'Reiniciar',
            'Reboot Server': 'Reiniciar servidor', 'Reload WebGUI': 'Recarregar WebGUI',
            'Reboot the entire server in one minute? Active scans and connections will be interrupted.':
                'Reiniciar todo o servidor em um minuto? Scans ativos e conexões serão interrompidos.',
            'System reboot scheduled': 'Reinicialização do sistema agendada',
            'The server will restart in': 'O servidor será reiniciado em',
            'Restarting now...': 'Reiniciando agora...',
            'Active scans and connections will be interrupted.':
                'Scans ativos e conexões serão interrompidos.',
            'WebGUI restart scheduled': 'Reinicialização da WebGUI agendada',
            'The WebGUI will restart in': 'A WebGUI será reiniciada em',
            'The page reconnects automatically when the service is back.':
                'A página será reconectada automaticamente quando o serviço voltar.',
            'Restart the WebGUI service in 10 seconds? The page will reconnect automatically.':
                'Reiniciar o serviço da WebGUI em 10 segundos? A página será reconectada automaticamente.',
            'No detections in this scan': 'Nenhuma detecção neste scan',
            'No quarantined files from this scan': 'Nenhum arquivo deste scan está em quarentena',
            'Restoring...': 'Restaurando...', 'Cleaning...': 'Limpando...',
            'Deleting...': 'Excluindo...', 'Restoring all...': 'Restaurando tudo...',
            'Quarantining...': 'Colocando em quarentena...', 'Quarantine': 'Quarentenar',
            'Restore': 'Restaurar', 'Clean': 'Limpar', 'Delete': 'Excluir',
            'Restore all': 'Restaurar tudo', 'Send Test Alert': 'Enviar alerta de teste',
            'Sending...': 'Enviando...', 'Saving...': 'Salvando...',
            'Maintenance complete': 'Manutenção concluída', 'Purge complete': 'Limpeza concluída',
            'Clear all logs, quarantine, and temp data?':
                'Limpar todos os logs, a quarentena e os dados temporários?',
            'Please fill in all password fields.': 'Preencha todos os campos de senha.',
            'New password must contain at least 8 characters.': 'A nova senha deve ter no mínimo 8 caracteres.',
            'New passwords do not match.': 'As novas senhas não coincidem.',
            'Password changed successfully.': 'Senha alterada com sucesso.',
            'Password (minimum 8 characters)': 'Senha (mínimo 8 caracteres)',
            'Error': 'Erro', 'Network error': 'Erro de rede',
            'Request timed out': 'Tempo limite da requisição excedido'
        }
    };
    function tr(text) {
        return I18N.lang === 'pt-BR' ? (I18N.pt[text] || text) : text;
    }
    function translateDom(root) {
        if (I18N.lang !== 'pt-BR') return;
        var walker = document.createTreeWalker(root || document.body, NodeFilter.SHOW_TEXT);
        var node;
        while ((node = walker.nextNode())) {
            var value = node.nodeValue.trim();
            if (value && I18N.pt[value]) node.nodeValue = node.nodeValue.replace(value, I18N.pt[value]);
        }
        var elements = (root || document.body).querySelectorAll ?
            (root || document.body).querySelectorAll('[title], [placeholder], [aria-label]') : [];
        for (var i = 0; i < elements.length; i++) {
            ['title', 'placeholder', 'aria-label'].forEach(function(attribute) {
                var value = elements[i].getAttribute(attribute);
                if (value && I18N.pt[value]) elements[i].setAttribute(attribute, I18N.pt[value]);
            });
        }
        document.documentElement.lang = 'pt-BR';
    }
    function applyLanguage() {
        var select = document.getElementById('language-select');
        if (select) select.value = I18N.lang;
        document.documentElement.lang = I18N.lang;
        translateDom(document.body);
        Router.navigate(Router.currentPage);
    }

    // ----- Status Indicator (sidebar footer) -----
    var _statusTimer = null;
    var _scanManagementTimer = null;
    var _scanManagementInterval = 5000;
    var _scanPreparing = false;
    var _scanStartInFlight = false;
    var _scanCompletionPending = false;
    var _scanCompletionIds = {};
    var _scanCompletionPrompted = {};
    function updateStatusIndicator() {
        API.get('/system', { timeout: 5000 }).then(function(data) {
            var sys = data.system || {};
            var dot = document.getElementById('status-dot');
            var text = document.getElementById('status-text');
            if (!dot || !text) return;
            var md = sys.maldet_path;
            if (!md) {
                dot.className = 'status-dot offline';
                text.textContent = 'maldet not found';
                return;
            }
            var running = !!sys.monitor_running;
            dot.className = 'status-dot ' + (running ? 'online' : 'warn');
            text.textContent = running ? 'Online · Monitor ON' : 'Online · Monitor OFF';
        }).catch(function() {
            var dot = document.getElementById('status-dot');
            var text = document.getElementById('status-text');
            if (!dot || !text) return;
            dot.className = 'status-dot offline';
            text.textContent = 'Offline';
        });
    }
    function initStatusIndicator() {
        if (_statusTimer) clearInterval(_statusTimer);
        updateStatusIndicator();
        _statusTimer = setInterval(updateStatusIndicator, 5000);
    }

    // ----- Page auto-refresh -----
    // Silently re-renders the current page so it always shows fresh data.
    // Config is excluded (editing form) and Scan Management has its own
    // faster live refresh. Refresh pauses while the user is interacting
    // (focused field, edited input, open modal, started an action) so no
    // typed data or in-progress feedback is ever wiped.
    var PAGE_AUTO_REFRESH_MS = 10000;
    var PAGE_AUTO_REFRESH_EXCLUDE = { config: true, 'scan-management': true };
    var _pageRefreshTimer = null;
    var _pageRefreshInFlight = false;
    var _pageDirty = false;
    var _pageRenderSeq = 0;
    var _lastPageHtml = '';

    function stopPageAutoRefresh() {
        if (_pageRefreshTimer) { clearInterval(_pageRefreshTimer); _pageRefreshTimer = null; }
    }

    function startPageAutoRefresh(name) {
        stopPageAutoRefresh();
        if (PAGE_AUTO_REFRESH_EXCLUDE[name]) return;
        _pageRefreshTimer = setInterval(pageAutoRefreshTick, PAGE_AUTO_REFRESH_MS);
    }

    function pageIsBusy(content) {
        if (_pageDirty || document.hidden) return true;
        if (document.querySelector('.modal-backdrop')) return true;
        var ae = document.activeElement;
        return !!(ae && content.contains(ae) && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName));
    }

    function pageAutoRefreshTick() {
        var name = Router.currentPage;
        var content = document.getElementById('content');
        if (!content || PAGE_AUTO_REFRESH_EXCLUDE[name] || !Router.routes[name]) return;
        if (_pageRefreshInFlight || pageIsBusy(content)) return;
        var seq = _pageRenderSeq;
        _pageRefreshInFlight = true;
        Promise.resolve(Router.routes[name]()).then(function(html) {
            if (seq !== _pageRenderSeq || Router.currentPage !== name) return;
            if (html === _lastPageHtml || pageIsBusy(content)) return;
            var scroll = content.scrollTop;
            content.innerHTML = html;
            translateDom(content);
            content.scrollTop = scroll;
            _lastPageHtml = html;
            if (name === 'dashboard') refreshDashboardUsage();
        }).catch(function() {
            // Silent: transient polling errors must not replace the page.
        }).then(function() { _pageRefreshInFlight = false; });
    }

    function markPageDirty(e) {
        var content = document.getElementById('content');
        if (!content || !content.contains(e.target)) return;
        if (e.type === 'click') {
            var el = e.target.closest('[data-action]');
            if (!el) return;
            var action = el.getAttribute('data-action') || '';
            if (action === 'refresh' || /-details(-close)?$/.test(action)) return;
        }
        _pageDirty = true;
    }

    // ----- Router -----
    var Router = {
        currentPage: 'dashboard',
        routes: {},
        register: function(name, fn) { this.routes[name] = fn; },
        navigate: function(name) {
            if (this.currentPage === 'scan-management' && name !== 'scan-management') {
                stopScanManagementRefresh();
            }
            if (this.currentPage === 'monitoring' && name !== 'monitoring') {
                stopMonitorActivityRefresh();
            }
            if (this.currentPage === 'dashboard' && name !== 'dashboard') {
                stopDashboardRefresh();
            }
            stopPageAutoRefresh();
            _pageRenderSeq++;
            _pageDirty = false;
            var renderSeq = _pageRenderSeq;
            this.currentPage = name;
            var items = document.querySelectorAll('.nav-item');
            for (var i = 0; i < items.length; i++) {
                items[i].classList.remove('active');
                if (items[i].dataset.page === name) items[i].classList.add('active');
            }
            var titles = {
                dashboard: tr('Dashboard'), scanner: tr('Scanner'), 'scan-management': tr('Scan Management'),
                quarantine: tr('Quarantine'), reports: tr('Reports'), monitoring: tr('Monitoring'),
                updates: tr('Updates'), security: tr('Security'), config: tr('Configuration'), alerts: tr('Test Alerts'),
                logs: tr('Logs'), ignore: tr('Ignore Lists'), maintenance: tr('Maintenance'), system: tr('System Info'),
                about: tr('About Maldet'), schedules: tr('Schedules')
            };
            document.getElementById('page-title').textContent = titles[name] || name;
            var content = document.getElementById('content');
            content.innerHTML = '<div class="loading">Loading...</div>';
            var self = this;
            if (this.routes[name]) {
                Promise.resolve(this.routes[name]()).then(function(html) {
                    content.innerHTML = html;
                    translateDom(content);
                    if (name === 'scan-management') startScanManagementRefresh();
                    if (name === 'monitoring') startMonitorActivityRefresh();
                    if (name === 'dashboard') startDashboardRefresh();
                    if (renderSeq === _pageRenderSeq) {
                        _lastPageHtml = html;
                        startPageAutoRefresh(name);
                    }
                }).catch(function(err) {
                    content.innerHTML = '<div class="card"><p style="color:red;">Error: ' + escapeHtml(err.message) + '</p></div>';
                });
            }
        },
        init: function() {
            var self = this;
            document.getElementById('sidebar-nav').addEventListener('click', function(e) {
                var item = e.target.closest('.nav-item');
                if (item) {
                    e.preventDefault();
                    self.navigate(item.dataset.page);
                    document.getElementById('sidebar').classList.remove('open');
                }
            });
            var mobileMenu = document.getElementById('mobile-menu-btn');
            if (mobileMenu) {
                mobileMenu.addEventListener('click', function() {
                    document.getElementById('sidebar').classList.toggle('open');
                });
            }
            var languageSelect = document.getElementById('language-select');
            if (languageSelect) {
                languageSelect.value = I18N.lang;
                languageSelect.addEventListener('change', function() {
                    I18N.lang = this.value;
                    localStorage.setItem('maldet.gui.language', I18N.lang);
                    // Reload from the original English template so switching
                    // back from Portuguese never leaves mixed-language nodes.
                    window.location.reload();
                });
            }
            document.getElementById('refresh-btn').addEventListener('click', function() {
                self.navigate(self.currentPage);
            });
            var settingsBtn = document.getElementById('settings-btn');
            if (settingsBtn) {
                settingsBtn.addEventListener('click', function() {
                    self.navigate('config');
                });
            }
            initRebootButton();
            initReloadGuiButton();
            document.addEventListener('input', markPageDirty, true);
            document.addEventListener('change', markPageDirty, true);
            document.addEventListener('click', markPageDirty, true);
            // Pressing Enter in the monitored-folder field adds it to the list.
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' && e.target && e.target.id === 'monitor-path-input') {
                    e.preventDefault();
                    addMonitorPath();
                }
            });
            // Delegated click handler for all dynamically rendered buttons/tabs.
            // Uses data-action attributes (CSP-safe, no inline onclick needed).
            document.addEventListener('click', function(e) {
                var el = e.target.closest('[data-action]');
                if (!el) return;
                var action = el.getAttribute('data-action');
                if (action === 'start-scan') startScan();
                else if (action === 'folder-picker') openFolderPicker(el.getAttribute('data-target'), el.getAttribute('data-title'));
                else if (action === 'scan-details') openScanDetails(el.getAttribute('data-id'));
                else if (action === 'scan-details-close') closeScanDetails();
                else if (action === 'report-details') openReportDetails(el.getAttribute('data-id'));
                else if (action === 'report-details-close') closeReportDetails();
                else if (action === 'folder-up') browseFolder(el.getAttribute('data-path'));
                else if (action === 'folder-select') selectFolder(el.getAttribute('data-path'));
                else if (action === 'folder-close') closeFolderPicker();
                else if (action === 'scan-stop') stopScan(el.getAttribute('data-id'));
                else if (action === 'scan-quarantine') scanAction(el.getAttribute('data-id'), 'quarantine');
                else if (action === 'scan-restore') scanAction(el.getAttribute('data-id'), 'restore');
                else if (action === 'scan-continue') resumeScan(el.getAttribute('data-id'));
                else if (action === 'scan-kill') discardScan(el.getAttribute('data-id'));
                else if (action === 'quarantine-details') openQuarantineDetails(el.getAttribute('data-file'));
                else if (action === 'quarantine-details-close') closeQuarantineDetails();
                else if (action === 'quarantine-restore') restoreQuarantineFile(el.getAttribute('data-file'));
                else if (action === 'quarantine-clean') cleanQuarantineFile(el.getAttribute('data-file'));
                else if (action === 'quarantine-delete') deleteQuarantineFile(el.getAttribute('data-file'));
                else if (action === 'quarantine-restore-all') restoreAllQuarantineFiles();
                else if (action === 'monitor-start') monitorStart();
                else if (action === 'monitor-stop') monitorStop();
                else if (action === 'monitor-reload') monitorReload();
                else if (action === 'monitor-save-users') saveMonitorUsers();
                else if (action === 'monitor-save-scope') saveMonitorScope();
                else if (action === 'monitor-save-webserver') saveMonitorWebserver();
                else if (action === 'monitor-save-mail') saveMonitorMail();
                else if (action === 'monitor-add-path') addMonitorPath();
                else if (action === 'monitor-remove-path') removeMonitorPath(el.getAttribute('data-path'));
                else if (action === 'monitor-save-paths') saveMonitorPaths();
                else if (action === 'update-ver') updateVer(false);
                else if (action === 'update-ver-beta') updateVer(true);
                else if (action === 'update-clamav') updateClamAv();
                else if (action === 'update-sigs') updateSigs();
                else if (action === 'save-config') saveConfig();
                else if (action === 'config-toggle-section') toggleConfigSection(el);
                else if (action === 'config-tip-toggle') toggleConfigTip(el);
                else if (action === 'config-expand-all') setAllConfigSections(true);
                else if (action === 'config-collapse-all') setAllConfigSections(false);
                else if (action === 'change-password') changePassword();
                else if (action === 'security-change-password') securityChangePassword();
                else if (action === 'send-alert') sendAlert();
                else if (action === 'ignore-tab') showIgnoreTab(el.getAttribute('data-name'));
                else if (action === 'save-ignore') saveIgnore(el.getAttribute('data-name'), el);
                else if (action === 'scanner-tab') switchScannerTab(el.getAttribute('data-tab'));
                else if (action === 'run-maint') runMaint();
                else if (action === 'run-purge') runPurge();
                else if (action === 'about-language') document.getElementById('language-select').focus();
                else if (action === 'about-refresh') Router.navigate('about');
                else if (action === 'about-settings') Router.navigate('config');
                else if (action === 'refresh') Router.navigate(Router.currentPage);
                else if (action === 'cron-file-toggle') toggleCronFile(el);
                else if (action === 'schedule-new') openScheduleModal(null);
                else if (action === 'schedule-edit') openScheduleModal(el.getAttribute('data-id'));
                else if (action === 'schedule-toggle') scheduleAction(el.getAttribute('data-id'), 'toggle');
                else if (action === 'schedule-delete') scheduleAction(el.getAttribute('data-id'), 'delete');
                else if (action === 'schedule-reports') openScheduleReports(el.getAttribute('data-id'));
            });
            document.getElementById('content').addEventListener('change', function(e) {
                if (e.target && e.target.id === 'scan_type') updateScanTypeFields(e.target.value);
                if (e.target && e.target.id === 'scan_engine') updateScanEngineHelp();
                if (e.target && e.target.matches('input[data-key]')) updateConfigFieldState(e.target);
            });
            document.getElementById('content').addEventListener('input', function(e) {
                if (e.target && (e.target.id === 'scan_path' || e.target.id === 'scan_days')) updateScanSummary();
                if (e.target && e.target.id === 'config-search') filterConfigOptions(e.target.value);
                if (e.target && e.target.matches('input[type="text"][data-key]')) updateConfigFieldState(e.target);
            });
            this.navigate('dashboard');
            translateDom(document.body);
        }
    };

    // ----- Dashboard -----
    // ----- Dashboard resource gauges (CPU/RAM, live) -----
    var GAUGE_CIRCUMFERENCE = 2 * Math.PI * 45;
    var _dashboardUsageTimer = null;

    function buildGaugeHtml(metric, label) {
        return '<div class="gauge-item">' +
            '<div class="gauge" data-gauge="' + metric + '">' +
            '<svg class="gauge-svg" viewBox="0 0 100 100">' +
            '<circle class="gauge-track" cx="50" cy="50" r="45"></circle>' +
            '<circle class="gauge-value" cx="50" cy="50" r="45" ' +
            'style="stroke-dasharray:' + GAUGE_CIRCUMFERENCE.toFixed(2) + ';stroke-dashoffset:' + GAUGE_CIRCUMFERENCE.toFixed(2) + ';"></circle>' +
            '</svg>' +
            '<div class="gauge-center"><span class="gauge-percent">--</span><span class="gauge-percent-sign">%</span></div>' +
            '</div>' +
            '<div class="gauge-label">' + escapeHtml(label) + '</div>' +
            '<div class="gauge-sub" data-gauge-sub="' + metric + '">' + tr('Waiting for data...') + '</div>' +
            '</div>';
    }

    function setGaugeValue(metric, percent) {
        var container = document.querySelector('[data-gauge="' + metric + '"]');
        if (!container) return;
        var circle = container.querySelector('.gauge-value');
        var text = container.querySelector('.gauge-percent');
        if (percent === null || percent === undefined || isNaN(percent)) {
            if (text) text.textContent = '--';
            return;
        }
        var pct = Math.max(0, Math.min(100, percent));
        if (circle) {
            circle.style.strokeDashoffset = (GAUGE_CIRCUMFERENCE * (1 - pct / 100)).toFixed(2);
            circle.classList.remove('warning', 'danger');
            if (pct >= 85) circle.classList.add('danger');
            else if (pct >= 60) circle.classList.add('warning');
        }
        if (text) text.textContent = Math.round(pct);
    }

    function formatMb(mb) {
        mb = mb || 0;
        if (mb >= 1024) return (mb / 1024).toFixed(1) + ' GB';
        return Math.round(mb) + ' MB';
    }

    function refreshDashboardUsage() {
        API.get('/system/usage').then(function(data) {
            setGaugeValue('cpu', data.cpu_percent);
            setGaugeValue('ram', data.mem_percent);
            var cpuSub = document.querySelector('[data-gauge-sub="cpu"]');
            if (cpuSub) {
                cpuSub.textContent = (data.cpu_percent === null || data.cpu_percent === undefined)
                    ? tr('Waiting for data...') : tr('Live');
            }
            var ramSub = document.querySelector('[data-gauge-sub="ram"]');
            if (ramSub && data.mem_total_mb) {
                ramSub.textContent = formatMb(data.mem_used_mb) + ' / ' + formatMb(data.mem_total_mb);
            }
        }).catch(function() {
            // Silent: transient polling errors shouldn't spam the user with
            // toasts every few seconds while the dashboard is open.
        });
    }

    function startDashboardRefresh() {
        stopDashboardRefresh();
        refreshDashboardUsage();
        _dashboardUsageTimer = setInterval(refreshDashboardUsage, 3000);
    }

    function stopDashboardRefresh() {
        if (_dashboardUsageTimer) { clearInterval(_dashboardUsageTimer); _dashboardUsageTimer = null; }
    }

    function renderDashboard() {
        return API.get('/system').then(function(data) {
            var sys = data.system;
            var h = '';
            h += '<div class="card" style="margin-bottom:20px;"><div class="card-header"><span class="card-title">' + tr('Resource Usage') + '</span></div>';
            h += '<div class="gauge-row">' + buildGaugeHtml('cpu', tr('CPU')) + buildGaugeHtml('ram', tr('RAM')) + '</div>';
            h += '</div>';
            h += '<div class="grid grid-4" style="margin-bottom:20px;">';
            h += '<div class="stat"><div class="stat-value">' + escapeHtml(sys.version || 'unknown') + '</div><div class="stat-label">Maldet Version</div></div>';
            h += '<div class="stat"><div class="stat-value">' + escapeHtml(sys.signature_version || '?') + '</div><div class="stat-label">Signature Set</div></div>';
            h += '<div class="stat ' + (sys.clamav_available ? 'success' : 'danger') + '"><div class="stat-value">' + escapeHtml(sys.clamav_version || '?') + '</div><div class="stat-label">ClamAV Status</div></div>';
            h += '<div class="stat success"><div class="stat-value">' + (sys.active_scans ? sys.active_scans.length : 0) + '</div><div class="stat-label">Active Scans</div></div>';
            h += '<div class="stat ' + (sys.monitor_running ? 'success' : 'danger') + '"><div class="stat-value">' + (sys.monitor_running ? 'ONLINE' : 'OFFLINE') + '</div><div class="stat-label">Monitor</div></div>';
            h += '</div>';
            h += '<div class="card"><div class="card-header"><span class="card-title">System Information</span></div>';
            h += '<div class="grid grid-2"><div><table>';
            h += '<tr><th>Hostname</th><td>' + escapeHtml(sys.hostname) + '</td></tr>';
            h += '<tr><th>OS</th><td>' + escapeHtml(sys.system) + ' ' + escapeHtml(sys.release) + '</td></tr>';
            h += '<tr><th>CPU</th><td>' + escapeHtml(sys.cpu || 'unknown') + ' (' + (sys.cpu_cores || 0) + ' cores)</td></tr>';
            h += '</table></div><div><table>';
            h += '<tr><th>Memory</th><td>' + (sys.mem_total_mb || 0) + ' MB total / ' + (sys.mem_available_mb || 0) + ' MB available</td></tr>';
            h += '<tr><th>Disk</th><td>' + (sys.disk_total_gb || 0) + ' GB total / ' + (sys.disk_free_gb || 0) + ' GB free</td></tr>';
            h += '<tr><th>Install Path</th><td>' + escapeHtml(sys.base_dir) + '</td></tr>';
            h += '<tr><th>Log Directory</th><td>' + escapeHtml(sys.log_dir) + '</td></tr>';
            h += '<tr><th>ClamAV</th><td>' + escapeHtml(sys.clamav_version || 'unknown') + ' (' + escapeHtml(sys.clamav_status || 'missing') + ')</td></tr>';
            h += '</table></div></div></div>';
            h += '<div class="card" style="margin-top:16px;"><div class="card-header"><span class="card-title">Binary Detection</span></div>';
            h += '<table><thead><tr><th>Binary</th><th>Path</th><th>Status</th></tr></thead><tbody>';
            var binaries = sys.binaries || {};
            for (var name in binaries) {
                var path = binaries[name];
                h += '<tr><td>' + escapeHtml(name) + '</td><td>' + escapeHtml(path || 'not found') + '</td>';
                h += '<td>' + (path ? '<span class="badge bg-success">Found</span>' : '<span class="badge bg-danger">Missing</span>') + '</td></tr>';
            }
            h += '</tbody></table></div>';
            return h;
        });
    }

    // ----- Scanner -----
    function renderScanner() {
        return Promise.all([API.get('/config'), API.get('/system')]).then(function(results) {
            var data = results[0];
            var sys = (results[1] && results[1].system) || {};
            var cm = {};
            for (var k in data.config) cm[k] = data.config[k].value;
            var clamavAvailable = sys.clamav_status === 'available';
            var h = '<div class="card"><div class="card-header"><span class="card-title">Scan Configuration</span></div>';
            h += '<div class="tabs"><div class="tab active" data-action="scanner-tab" data-tab="basic">Basic</div>';
            h += '<div class="tab" data-action="scanner-tab" data-tab="adv">Advanced</div></div>';
            h += '<div id="tab-basic"><div class="form-group"><label class="form-label">Scan Type</label>';
            h += '<select class="form-input" id="scan_type"><option value="all">Full Scan</option><option value="recent">Recent Scan</option></select><small class="form-help" id="scan_type_help">Scans all files below the selected path.</small></div>';
            h += '<div class="form-group"><label class="form-label">Scanner engine</label>';
            h += '<select class="form-input" id="scan_engine"><option value="native">Maldet nativo (MD5/SHA256/HEX/YARA)</option>';
            h += '<option value="clamscan"' + (clamavAvailable ? '' : ' disabled') + '>ClamAV (clamscan)' + (clamavAvailable ? '' : ' — não instalado') + '</option></select>';
            h += '<small class="form-help" id="scan_engine_help">Mecanismo nativo do Maldet: mais rápido, assinaturas MD5/HEX/YARA próprias.</small></div>';
            h += '<div class="form-group"><label class="form-label">Path</label><div class="path-picker-row"><input type="text" class="form-input" id="scan_path" value="/home" required placeholder="/home/user"><button type="button" class="btn btn-ghost" data-action="folder-picker">Browse</button></div><small class="form-help">Choose a folder or enter an absolute directory path manually.</small></div>';
            h += '<div class="form-group" id="scan_days_group" style="display:none;"><label class="form-label">Modified within (days)</label><input type="number" class="form-input" id="scan_days" value="2" min="1" step="1"><small class="form-help">Only files modified in this many days will be scanned.</small></div></div>';
            h += '<div id="tab-adv" style="display:none;"><div class="form-group"><label class="form-label">Config Overrides (-co)</label><input type="text" class="form-input" id="scan_co" placeholder="scan_yara=1,scan_hashtype=sha256"></div>';
            h += '<div class="form-group"><label class="form-label">Include Regex (-i)</label><input type="text" class="form-input" id="scan_inc" placeholder=".*\\.php$"></div>';
            h += '<div class="form-group"><label class="form-label">Exclude Regex (-x)</label><input type="text" class="form-input" id="scan_exc" placeholder=".*\\.log"></div></div>';
            h += '<div class="form-group"><label class="form-label">Options</label><label style="font-size:13px;"><input type="checkbox" id="scan_bg" checked> Run in background (recommended)</label></div>';
            h += '<div id="scan_summary" class="alert alert-info">Ready to scan <strong>Full Scan</strong> on <code>/home</code>. No scan has started yet.</div>';
            h += '<button class="btn btn-primary" id="start-scan-btn" data-action="start-scan">Start Scan</button></div>';
            return h;
        });
    }

    function updateScanEngineHelp() {
        var engineEl = document.getElementById('scan_engine');
        var help = document.getElementById('scan_engine_help');
        if (!engineEl || !help) return;
        help.textContent = engineEl.value === 'clamscan' ?
            'ClamAV: usa o antivírus do sistema (clamscan) e o banco de assinaturas do ClamAV.' :
            'Mecanismo nativo do Maldet: mais rápido, assinaturas MD5/HEX/YARA próprias.';
        updateScanSummary();
    }


    function updateScanTypeFields(type) {
        var daysGroup = document.getElementById('scan_days_group');
        var help = document.getElementById('scan_type_help');
        if (daysGroup) daysGroup.style.display = type === 'recent' ? 'block' : 'none';
        if (help) help.textContent = type === 'recent' ? 'Scans files changed within the selected number of days.' :
            'Scans all files below the selected path.';
        updateScanSummary();
    }

    function updateScanSummary() {
        var path = document.getElementById('scan_path');
        var type = document.getElementById('scan_type');
        var days = document.getElementById('scan_days');
        var engine = document.getElementById('scan_engine');
        var summary = document.getElementById('scan_summary');
        if (!path || !type || !summary) return;
        var label = type.options[type.selectedIndex].text;
        var value = path.value.trim() || '(enter a path)';
        var detail = type.value === 'recent' ? ' · modified within ' +
            escapeHtml((days && days.value) || '2') + ' day(s)' : '';
        var engineLabel = engine ? ' · engine: ' + escapeHtml(engine.value === 'clamscan' ? 'ClamAV' : 'Maldet nativo') : '';
        summary.innerHTML = 'Ready to run <strong>' + escapeHtml(label) + '</strong> on <code>' +
            escapeHtml(value) + '</code>' + detail + engineLabel + '. <span>No scan has started yet.</span>';
    }

    var _folderPickerTargetId = 'scan_path';

    function closeFolderPicker() {
        var modal = document.getElementById('folder-picker-modal');
        if (modal) modal.remove();
    }

    function selectFolder(path) {
        var input = document.getElementById(_folderPickerTargetId);
        if (input) {
            input.value = path;
            input.dispatchEvent(new Event('input', { bubbles: true }));
            if (_folderPickerTargetId === 'scan_path') updateScanSummary();
        }
        var targetId = _folderPickerTargetId;
        closeFolderPicker();
        // In the monitored-folders card the picker doubles as a shortcut for
        // the "Add folder" button, so queue the chosen folder right away.
        if (targetId === 'monitor-path-input') addMonitorPath();
    }

    function browseFolder(path) {
        var body = document.getElementById('folder-picker-body');
        if (body) body.innerHTML = '<p class="form-help">Loading folders...</p>';
        API.get('/directories?path=' + encodeURIComponent(path)).then(function(data) {
            var rows = '';
            if (data.parent !== null && data.parent !== undefined) {
                rows += '<button class="folder-entry folder-parent" data-action="folder-up" data-path="' + escapeHtml(data.parent) + '">↩ ..</button>';
            }
            (data.directories || []).forEach(function(dir) {
                rows += '<button class="folder-entry" data-action="folder-enter" data-path="' + escapeHtml(dir.path) + '">📁 ' + escapeHtml(dir.name) + '<span class="folder-entry-hint">Open</span></button>';
            });
            var current = document.getElementById('folder-picker-path');
            if (body) body.innerHTML = rows || '<p class="form-help">No subfolders found.</p>';
            if (current) current.textContent = data.path;
            var select = document.getElementById('folder-select-current');
            if (select) {
                select.disabled = false;
                select.setAttribute('data-path', data.path);
            }
        }).catch(function(err) {
            if (body) body.innerHTML = '<p class="form-help folder-error">Cannot read this directory: ' + escapeHtml(err.message) + '</p>';
            var select = document.getElementById('folder-select-current');
            if (select) select.disabled = true;
        });
    }

    function openFolderPicker(targetId, title) {
        _folderPickerTargetId = targetId || 'scan_path';
        closeFolderPicker();
        var modal = document.createElement('div');
        modal.id = 'folder-picker-modal';
        modal.className = 'modal-backdrop';
        modal.innerHTML = '<div class="modal"><div class="modal-header"><span class="modal-title">' + tr(title || 'Choose scan folder') + '</span>' +
            '<button class="modal-close" data-action="folder-close">×</button></div><div class="modal-body">' +
            '<div class="folder-current" id="folder-picker-path">Loading...</div><div id="folder-picker-body" class="folder-list"></div></div>' +
            '<div class="modal-footer"><button class="btn btn-ghost" data-action="folder-close">Cancel</button>' +
            '<button class="btn btn-primary" id="folder-select-current" data-action="folder-select" disabled>Select this folder</button></div></div>';
        document.body.appendChild(modal);
        modal.addEventListener('click', function(e) {
            var el = e.target.closest('[data-action]');
            if (!el) return;
            var action = el.getAttribute('data-action');
            if (action === 'folder-close') closeFolderPicker();
            else if (action === 'folder-up') browseFolder(el.getAttribute('data-path'));
            else if (action === 'folder-enter') browseFolder(el.getAttribute('data-path'));
            else if (action === 'folder-select') selectFolder(el.getAttribute('data-path'));
        });
        var targetInput = document.getElementById(_folderPickerTargetId);
        browseFolder((targetInput && targetInput.value.trim()) || '/');
    }

    function switchScannerTab(tab) {
        var basic = document.getElementById('tab-basic');
        var adv = document.getElementById('tab-adv');
        if (tab === 'adv') {
            if (basic) basic.style.display = 'none';
            if (adv) adv.style.display = 'block';
        } else {
            if (basic) basic.style.display = 'block';
            if (adv) adv.style.display = 'none';
        }
    }

    function startScan() {
        if (_scanStartInFlight) return;
        var scanTypeEl = document.getElementById('scan_type');
        var scanPathEl = document.getElementById('scan_path');
        var scanDaysEl = document.getElementById('scan_days');
        var scanEngineEl = document.getElementById('scan_engine');
        var scanCoEl = document.getElementById('scan_co');
        var scanIncEl = document.getElementById('scan_inc');
        var scanExcEl = document.getElementById('scan_exc');
        var scanBgEl = document.getElementById('scan_bg');
        if (!scanTypeEl || !scanPathEl) {
            toast('Scan form not loaded yet - please wait and try again', 'error');
            return;
        }
        var type = scanTypeEl.value;
        var path = scanPathEl.value.trim();
        if (!path) {
            toast('Enter a scan path before starting', 'error');
            scanPathEl.focus();
            return;
        }
        if (type === 'recent' && (!scanDaysEl.value || parseInt(scanDaysEl.value, 10) < 1)) {
            toast('Recent scans require at least 1 day', 'error');
            scanDaysEl.focus();
            return;
        }
        var button = document.getElementById('start-scan-btn');
        var body = {
            type: type,
            path: path,
            days: (scanDaysEl && scanDaysEl.value) || '2',
            engine: (scanEngineEl && scanEngineEl.value) || 'native',
            config_overrides: (scanCoEl && scanCoEl.value) || '',
            include_regex: (scanIncEl && scanIncEl.value) || '',
            exclude_regex: (scanExcEl && scanExcEl.value) || '',
            background: !!(scanBgEl && scanBgEl.checked)
        };
        if (button) {
            button.disabled = true;
            button.textContent = 'Starting...';
        }
        toast('Preparing scan...', 'info');
        if (button) button.textContent = 'Preparing...';
        setTimeout(function() {
            if (button && button.disabled) button.textContent = 'Starting...';
        }, 500);
        _scanPreparing = true;
        _scanStartInFlight = true;
        API.post('/scan', body).then(function(resp) {
            _scanPreparing = false;
            _scanStartInFlight = false;
            if (resp.scan_started) {
                _scanCompletionPending = true;
                _scanCompletionIds = {};
                _scanCompletionPrompted = {};
            }
            if (resp.hits_found) toast('Scan complete - hits found!', 'error');
            else if (resp.clean) toast('Scan complete - no malware', 'success');
            else if (resp.scan_started) toast('Scan started in background', 'success');
            else toast(resp.message || 'Scan started', 'info');
            Router.navigate(resp.scan_started ? 'scan-management' : 'reports');
        }).catch(function(e) {
            _scanPreparing = false;
            _scanStartInFlight = false;
            toast('Error: ' + e.message, 'error');
            Router.navigate('scan-management');
        });
    }

    // ----- Scan Management -----
    function buildScanManagementHtml(active) {
        var unique = {};
        active = active.filter(function(scan) {
            var id = scan && scan.scan_id;
            if (!id || unique[id]) return false;
            unique[id] = true;
            return true;
        });
        var refreshLabel = active.length > 0 ? 'Live updates every 3s' : 'Live updates every 5s';
        var h = '<div class="card"><div class="card-header"><span class="card-title">Active Scans (' + active.length + ')</span><span style="font-size:12px;color:var(--text-muted);">' + tr(refreshLabel) + '</span></div>';
        if (_scanPreparing) {
            h += '<div class="alert alert-info" style="margin:12px 0;"><strong>Preparing scan...</strong><br><small>Validating the path and starting the Maldet process.</small></div>';
        }
        if (active.length === 0) {
            h += '<p style="padding:12px;color:var(--text-muted);">No active scans.</p>';
        } else {
            h += '<table><thead><tr><th>Scan ID</th><th>Directory</th><th>State</th><th>Engine</th><th>PID</th><th>Files scanned</th><th>Total files</th><th>Hits</th><th>Elapsed</th><th>Actions</th></tr></thead><tbody>';
            for (var i = 0; i < active.length; i++) {
                var s = active[i];
                var progress = s.progress || {};
                var scanned = Number(progress.position || s.files_scanned || 0);
                var total = Number(progress.total || s.total_files || 0);
                var elapsed = Number(s.elapsed);
                var scanClockStarted = Number.isFinite(elapsed) && elapsed === 0;
                var progressStarted = total > 0 && (scanClockStarted || scanned > 0);
                var percent = progressStarted ? Math.min(100, Math.max(0, (scanned / total) * 100)) : 0;
                var progressText = progressStarted && total > 0 ? Math.round(percent) + '%' : '';
                var progressBar = progressStarted ? '<div class="scan-progress" role="progressbar" aria-label="Scan progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + Math.round(percent) + '">' +
                    '<div class="scan-progress-track"><div class="scan-progress-fill" style="width:' + percent.toFixed(1) + '%;"></div></div>' +
                    '<span class="scan-progress-label">' + progressText + '</span></div>' :
                    '<span class="form-help">Waiting for first file...</span>';
                var filesText = progressStarted ? (scanned + ' / ' + total) : 'Waiting for scan start';
                h += '<tr><td>' + escapeHtml(s.scan_id) + '</td><td style="font-size:12px;max-width:260px;word-break:break-all;">' + escapeHtml(s.path || '-') + '</td><td>' + escapeHtml(s.state) + '</td><td>' + escapeHtml(s.engine || '-') + '</td>';
                var hitCount = Number(s.hits || 0);
                var hitLabel = hitCount > 0 ?
                    '<span class="badge bg-danger">' + hitCount + ' detected</span>' :
                    '<span class="badge bg-success">No hits</span>';
                h += '<td>' + (s.pid || '-') + '</td><td>' + progressBar + '<div class="scan-files-count">' + filesText + '</div></td><td>' + (total > 0 ? total : '-') + '</td><td>' + hitLabel + '</td><td>' + fmtDuration(s.elapsed) + '</td>';
                h += '<td><button class="btn btn-ghost btn-sm" data-action="scan-details" data-id="' + escapeHtml(s.scan_id || '') + '">Details</button> ';
                h += '<button class="btn btn-danger btn-sm" data-action="scan-stop" data-id="' + escapeHtml(s.scan_id || '') + '">Stop</button></td></tr>';
            }
            h += '</tbody></table>';
        }
        return h + '</div>';
    }

    function refreshScanManagementView() {
        if (Router.currentPage !== 'scan-management') return;
        API.get('/scans/active').then(function(data) {
            if (Router.currentPage !== 'scan-management') return;
            var active = data.active_scans || [];
            if (_scanCompletionPending) {
                for (var i = 0; i < active.length; i++) {
                    if (active[i].scan_id) _scanCompletionIds[active[i].scan_id] = true;
                }
                if (active.length === 0) {
                    var completedId = Object.keys(_scanCompletionIds).filter(function(id) {
                        return !_scanCompletionPrompted[id];
                    })[0];
                    if (completedId) {
                        _scanCompletionPrompted[completedId] = true;
                        _scanCompletionPending = false;
                        if (window.confirm('Scan ' + completedId + ' concluído. Deseja exibir o relatório?')) {
                            Router.navigate('reports');
                        }
                    }
                }
            }
            var content = document.getElementById('content');
            if (content) content.innerHTML = buildScanManagementHtml(active);
            var desiredInterval = active.length > 0 ? 3000 : 5000;
            if (_scanManagementInterval !== desiredInterval) {
                _scanManagementInterval = desiredInterval;
                startScanManagementRefresh();
            }
        }).catch(function(err) {
            if (Router.currentPage !== 'scan-management') return;
            var content = document.getElementById('content');
            if (content) content.innerHTML = '<div class="card"><p style="color:red;">Error: ' + escapeHtml(err.message) + '</p></div>';
        });
    }

    function startScanManagementRefresh() {
        stopScanManagementRefresh();
        _scanManagementTimer = setInterval(refreshScanManagementView, _scanManagementInterval);
    }

    function stopScanManagementRefresh() {
        if (_scanManagementTimer) {
            clearInterval(_scanManagementTimer);
            _scanManagementTimer = null;
        }
    }

    function renderScanManagement() {
        return API.get('/scans/active').then(function(data) {
            var active = data.active_scans || [];
            _scanManagementInterval = active.length > 0 ? 3000 : 5000;
            return buildScanManagementHtml(active);
        });
    }

    function closeScanDetails() {
        var modal = document.getElementById('scan-details-modal');
        if (modal) modal.remove();
    }

    function openScanDetails(scanId) {
        closeScanDetails();
        var modal = document.createElement('div');
        modal.id = 'scan-details-modal';
        modal.className = 'modal-backdrop';
        modal.innerHTML = '<div class="modal scan-details-modal"><div class="modal-header"><span class="modal-title">Scan details</span>' +
            '<button class="modal-close" data-action="scan-details-close">×</button></div><div class="modal-body">' +
            '<div class="loading">Loading scan ' + escapeHtml(scanId) + '...</div></div>' +
            '<div class="modal-footer"><button class="btn btn-ghost" data-action="scan-details-close">Close</button></div></div>';
        document.body.appendChild(modal);
        modal.addEventListener('click', function(e) {
            var el = e.target.closest('[data-action]');
            if (el && el.getAttribute('data-action') === 'scan-details-close') closeScanDetails();
        });
        API.get('/scan/' + encodeURIComponent(scanId)).then(function(data) {
            var body = modal.querySelector('.modal-body');
            if (!body) return;
            var h = '';
            var detections = data.hits || data.detections || [];
            if (detections.length) {
                h += '<h4 style="margin:0 0 10px;">Detected files (' + detections.length + ')</h4>';
                h += '<div style="overflow-x:auto;"><table class="scan-details-table"><thead><tr><th>Signature</th><th>File</th><th>Type</th><th>Status</th></tr></thead><tbody>';
                detections.forEach(function(hit) {
                    var status = hit.quarantined ? 'Quarantined' : 'Detected';
                    h += '<tr><td><code>' + escapeHtml(hit.signature || '-') + '</code></td>' +
                        '<td style="word-break:break-all;">' + escapeHtml(hit.file || hit.path || '-') + '</td>' +
                        '<td>' + escapeHtml(hit.hit_type_label || hit.hit_type || '-') + '</td>' +
                        '<td>' + escapeHtml(status) + '</td></tr>';
                });
                h += '</tbody></table></div>';
            } else {
                h += '<p class="form-help">No detected files in this scan.</p>';
            }
            var entries = '';
            Object.keys(data).forEach(function(key) {
                if (key === 'hits' || key === 'detections') return;
                var value = data[key];
                if (value && typeof value === 'object') value = JSON.stringify(value);
                entries += '<tr><th>' + escapeHtml(key) + '</th><td>' + escapeHtml(value) + '</td></tr>';
            });
            if (entries) h += '<h4 style="margin:16px 0 10px;">Scan summary</h4><table class="scan-details-table"><tbody>' + entries + '</tbody></table>';
            body.innerHTML = h;
        }).catch(function(err) {
            var body = modal.querySelector('.modal-body');
            if (body) body.innerHTML = '<p style="color:var(--danger);">Error loading details: ' + escapeHtml(err.message) + '</p>';
        });
    }

    // ----- Quarantine -----
    function renderQuarantine() {
        return API.get('/quarantine').then(function(data) {
            var files = data.files || [];
            var h = '<div class="card"><div class="card-header"><span class="card-title">Quarantined Files (' + files.length + ')</span>';
            if (files.length) {
                h += '<button class="btn btn-primary btn-sm" data-action="quarantine-restore-all">Restore all</button>';
            }
            h += '</div>';
            if (files.length === 0) {
                h += '<p style="padding:12px;color:var(--text-muted);">No files in quarantine.</p>';
            } else {
                h += '<table><thead><tr><th>File</th><th>Signature</th><th>Original Path</th><th>Size</th><th>Actions</th></tr></thead><tbody>';
                for (var i = 0; i < files.length; i++) {
                    var f = files[i];
                    h += '<tr><td><code>' + escapeHtml(f.name) + '</code></td><td>' + escapeHtml(f.signature || '-') + '</td>';
                    h += '<td style="font-size:12px;">' + escapeHtml(f.original_path || '-') + '</td><td>' + fmtSize(f.size) + '</td>';
                    h += '<td><button class="btn btn-ghost btn-sm" data-action="quarantine-details" data-file="' + escapeHtml(f.name) + '">Details</button> ';
                    h += '<button class="btn btn-primary btn-sm" data-action="quarantine-restore" data-file="' + escapeHtml(f.name) + '">Restore</button> ';
                    h += '<button class="btn btn-warning btn-sm" data-action="quarantine-clean" data-file="' + escapeHtml(f.name) + '">Clean</button> ';
                    h += '<button class="btn btn-danger btn-sm" data-action="quarantine-delete" data-file="' + escapeHtml(f.name) + '">Delete</button></td></tr>';
                }
                h += '</tbody></table>';
            }
            h += '</div>';
            return h;
        });
    }

    function openQuarantineDetails(filename) {
        var old = document.getElementById('quarantine-details-modal');
        if (old) old.remove();
        var modal = document.createElement('div');
        modal.id = 'quarantine-details-modal';
        modal.className = 'modal-backdrop';
        modal.innerHTML = '<div class="modal"><div class="modal-header"><span class="modal-title">Infection details</span>' +
            '<button class="modal-close" data-action="quarantine-details-close">×</button></div>' +
            '<div class="modal-body"><p class="form-help">Loading details...</p></div>' +
            '<div class="modal-footer"><button class="btn btn-ghost" data-action="quarantine-details-close">Close</button></div></div>';
        document.body.appendChild(modal);
        API.get('/quarantine/details?file=' + encodeURIComponent(filename)).then(function(data) {
            var body = modal.querySelector('.modal-body');
            var rows = '';
            Object.keys(data).forEach(function(key) {
                var value = data[key];
                if (value && typeof value === 'object') value = JSON.stringify(value);
                rows += '<tr><th>' + escapeHtml(key) + '</th><td style="word-break:break-all;">' + escapeHtml(String(value)) + '</td></tr>';
            });
            body.innerHTML = '<table class="scan-details-table"><tbody>' + rows + '</tbody></table>';
        }).catch(function(err) {
            var body = modal.querySelector('.modal-body');
            body.innerHTML = '<p style="color:var(--danger);">Error loading details: ' + escapeHtml(err.message) + '</p>';
        });
    }

    function closeQuarantineDetails() {
        var modal = document.getElementById('quarantine-details-modal');
        if (modal) modal.remove();
    }

    function restoreQuarantineFile(filename) {
        if (!filename || !confirm('Restore ' + filename + '?')) return;
        var button = null;
        document.querySelectorAll('[data-action="quarantine-restore"]').forEach(function(candidate) {
            if (candidate.getAttribute('data-file') === filename) button = candidate;
        });
        if (button) {
            button.disabled = true;
            button.textContent = 'Restoring...';
        }
        API.post('/quarantine/restore', { file: filename }).then(function(data) {
            if (data.returncode !== undefined && data.returncode !== 0 && data.returncode !== 2) {
                throw new Error(data.stderr || data.stdout || 'Restore failed');
            }
            toast('File restored successfully', 'success');
            Router.navigate('quarantine');
        }).catch(function(err) {
            toast('Restore failed: ' + err.message, 'error');
            if (button) {
                button.disabled = false;
                button.textContent = 'Restore';
            }
        });
    }

    function cleanQuarantineFile(filename) {
        if (!filename || !confirm('Try to clean ' + filename + '?\n\nThe file is restored to its original location, cleaned with the matching maldet clean rule and rescanned. If cleaning fails, it is moved back to quarantine.')) return;
        var button = null;
        document.querySelectorAll('[data-action="quarantine-clean"]').forEach(function(candidate) {
            if (candidate.getAttribute('data-file') === filename) button = candidate;
        });
        if (button) {
            button.disabled = true;
            button.textContent = 'Cleaning...';
        }
        API.post('/quarantine/clean', { file: filename }).then(function(data) {
            if (data.returncode !== undefined && data.returncode !== 0 && data.returncode !== 2) {
                throw new Error(data.stderr || data.stdout || 'Clean failed');
            }
            if (data.cleaned) {
                toast('File cleaned successfully (restored to original path)', 'success');
            } else {
                toast('Clean attempted; no clean rule matched or cleaning failed — file remains in quarantine. Check the output: ' +
                    (data.stderr || data.stdout || '').trim().split('\n').slice(-1)[0], 'info', 8000);
            }
            Router.navigate('quarantine');
        }).catch(function(err) {
            toast('Clean failed: ' + err.message, 'error');
            if (button) {
                button.disabled = false;
                button.textContent = 'Clean';
            }
        });
    }

    function deleteQuarantineFile(filename) {
        if (!filename || !confirm('Permanently delete ' + filename + ' from quarantine?\n\nThis cannot be undone — the file will NOT be restored.')) return;
        var button = null;
        document.querySelectorAll('[data-action="quarantine-delete"]').forEach(function(candidate) {
            if (candidate.getAttribute('data-file') === filename) button = candidate;
        });
        if (button) {
            button.disabled = true;
            button.textContent = 'Deleting...';
        }
        API.post('/quarantine/delete', { file: filename }).then(function(data) {
            toast('Quarantined file deleted', 'success');
            Router.navigate('quarantine');
        }).catch(function(err) {
            toast('Delete failed: ' + err.message, 'error');
            if (button) {
                button.disabled = false;
                button.textContent = 'Delete';
            }
        });
    }

    function restoreAllQuarantineFiles() {
        var buttons = document.querySelectorAll('[data-action="quarantine-restore-all"]');
        if (!buttons.length || !confirm('Restore all quarantined files?')) return;
        buttons.forEach(function(button) {
            button.disabled = true;
            button.textContent = 'Restoring all...';
        });
        API.post('/quarantine/restore-all', {}).then(function(data) {
            if (data.failed) {
                toast('Restored ' + data.restored + '; failed: ' + data.failed, 'error');
            } else {
                toast('All quarantined files restored (' + data.restored + ')', 'success');
            }
            Router.navigate('quarantine');
        }).catch(function(err) {
            toast('Restore all failed: ' + err.message, 'error');
            buttons.forEach(function(button) {
                button.disabled = false;
                button.textContent = 'Restore all';
            });
        });
    }

    function openReportDetails(scanId) {
        var old = document.getElementById('report-details-modal');
        if (old) old.remove();
        var modal = document.createElement('div');
        modal.id = 'report-details-modal';
        modal.className = 'modal-backdrop';
        modal.innerHTML = '<div class="modal report-details-modal"><div class="modal-header"><span class="modal-title">Scan report</span>' +
            '<button class="modal-close" data-action="report-details-close">×</button></div>' +
            '<div class="modal-body"><div class="loading">Loading report ' + escapeHtml(scanId) + '...</div></div>' +
            '<div class="modal-footer"><button class="btn btn-ghost" data-action="report-details-close">Close</button></div></div>';
        document.body.appendChild(modal);
        API.get('/scan/' + encodeURIComponent(scanId)).then(function(data) {
            var body = modal.querySelector('.modal-body');
            if (!body) return;
            var report = data.reports && data.reports[0] ? data.reports[0] : data;
            var hits = report.hits || report.detections || [];
            var totalHits = Number(report.total_hits);
            if (!Number.isFinite(totalHits)) totalHits = hits.length;
            var h = '<div class="report-summary"><strong>' + totalHits + ' hit(s)</strong>';
            if (report.path) h += ' · ' + escapeHtml(report.path);
            if (report.completed) h += ' · ' + escapeHtml(report.completed);
            h += '</div>';
            if (hits.length) {
                h += '<table><thead><tr><th>File</th><th>Signature</th><th>Hash</th></tr></thead><tbody>';
                hits.forEach(function(hit) {
                    h += '<tr><td>' + escapeHtml(hit.file || hit.path || hit.filename || '-') + '</td>' +
                        '<td>' + escapeHtml(hit.signature || hit.sig || hit.name || '-') + '</td>' +
                        '<td><code>' + escapeHtml(hit.md5 || hit.hash || '-') + '</code></td></tr>';
                });
                h += '</tbody></table>';
            } else {
                h += '<p style="color:var(--text-muted);">No hit details were returned by Maldet.</p>';
            }
            h += '<details><summary>JSON completo</summary><pre class="report-json">' +
                escapeHtml(JSON.stringify(data, null, 2)) + '</pre></details>';
            body.innerHTML = h;
        }).catch(function(err) {
            var body = modal.querySelector('.modal-body');
            if (body) body.innerHTML = '<p style="color:var(--danger);">Error loading report: ' + escapeHtml(err.message) + '</p>';
        });
    }

    function closeReportDetails() {
        var modal = document.getElementById('report-details-modal');
        if (modal) modal.remove();
    }

    // ----- Reports -----
    function renderReports() {
        return API.get('/scans').then(function(data) {
            var reports = data.reports || [];
            var active = data.active || data.active_scans || [];
            var stopped = data.stopped || data.stopped_scans || [];
            var h = '<div class="card"><div class="card-header"><span class="card-title">' +
                tr('Scan Reports') + ' (' + reports.length + ')</span><button class="btn btn-ghost btn-sm" data-action="refresh">🔄</button></div>';
            if (active.length) {
                h += '<div class="alert alert-warning">' + escapeHtml(active.length + ' ' + tr('scan(s) still active.')) + '</div>';
            }
            if (stopped.length) {
                h += '<div class="alert alert-warning">' + escapeHtml(stopped.length + ' ' + tr('scan(s) stopped and resumable.')) + '</div>';
                h += '<div class="table-scroll"><table><thead><tr><th>' + tr('Scan ID') + '</th><th>' +
                    tr('Path') + '</th><th>' + tr('Started') + '</th><th>' + tr('Stopped') + '</th><th>' +
                    tr('Files') + '</th><th>' + tr('Hits') + '</th><th>' + tr('Actions') + '</th></tr></thead><tbody>';
                for (var si = 0; si < stopped.length; si++) {
                    var st = stopped[si];
                    var stScanId = String(st.scan_id || '');
                    h += '<tr><td><code>' + escapeHtml(stScanId || '-') + '</code></td>';
                    h += '<td style="font-size:12px;">' + escapeHtml(st.path || '-') + '</td><td>' + fmtTime(st.started_epoch) + '</td>';
                    h += '<td>' + escapeHtml(st.stopped || (st.stopped_epoch ? fmtTime(st.stopped_epoch) : '-')) + '</td>';
                    h += '<td>' + (Number(st.total_files) || 0) + '</td><td>' + (Number(st.total_hits) || 0) + '</td>';
                    h += '<td><button class="btn btn-primary btn-sm" data-action="scan-continue" data-id="' + escapeHtml(stScanId) + '">' + tr('Resume') + '</button> ';
                    h += '<button class="btn btn-danger btn-sm" data-action="scan-kill" data-id="' + escapeHtml(stScanId) + '">' + tr('Discard') + '</button></td></tr>';
                }
                h += '</tbody></table></div>';
            }
            if (reports.length === 0) {
                h += '<p style="padding:12px;color:var(--text-muted);">' + tr('No completed reports found.') + '</p>';
            } else {
                h += '<div class="table-scroll"><table><thead><tr><th>' + tr('Scan ID') + '</th><th>' +
                    tr('Path') + '</th><th>' + tr('Started') + '</th><th>' + tr('Completed') +
                    '</th><th>' + tr('Duration') + '</th><th>' + tr('Files') + '</th><th>' +
                    tr('Hits') + '</th><th>' + tr('Quarantined') + '</th><th>' + tr('Actions') +
                    '</th></tr></thead><tbody>';
                for (var i = 0; i < reports.length; i++) {
                    var r = reports[i];
                    var hits = Number(r.total_hits);
                    if (!Number.isFinite(hits)) hits = Array.isArray(r.hits) ? r.hits.length :
                        (r.summary && Number(r.summary.total_hits)) || 0;
                    var quarantined = Number(r.total_quarantined) || 0;
                    var scanId = String(r.scan_id || '');
                    h += '<tr><td><code>' + escapeHtml(scanId || '-') + '</code></td>';
                    h += '<td style="font-size:12px;">' + escapeHtml(r.path || '-') + '</td><td>' + fmtTime(r.started_epoch) + '</td>';
                    h += '<td>' + escapeHtml(r.completed || (r.completed_epoch ? fmtTime(r.completed_epoch) : '-')) + '</td>';
                    h += '<td>' + fmtDuration(r.elapsed_seconds) + '</td><td>' + (Number(r.total_files) || 0) + '</td><td>' + hits + '</td><td>' + quarantined + '</td>';
                    h += '<td><button class="btn btn-primary btn-sm" data-action="report-details" data-id="' + escapeHtml(scanId) + '">' + tr('Show Report') + '</button> ';
                    h += '<button class="btn btn-ghost btn-sm" data-action="scan-quarantine" data-id="' + escapeHtml(scanId) + '"' +
                        (hits === 0 ? ' disabled title="' + tr('No detections in this scan') + '"' : '') + '>' + tr('Quarantine') + '</button> ';
                    h += '<button class="btn btn-ghost btn-sm" data-action="scan-restore" data-id="' + escapeHtml(scanId) + '"' +
                        (quarantined === 0 ? ' disabled title="' + tr('No quarantined files from this scan') + '"' : '') + '>' + tr('Restore') + '</button></td></tr>';
                }
                h += '</tbody></table></div>';
            }
            h += '</div>';
            return h;
        });
    }

    var SCAN_ACTION_LABELS = {
        quarantine: { idle: 'Quarantine', working: 'Quarantining...' },
        restore: { idle: 'Restore', working: 'Restoring...' },
        stop: { idle: 'Stop', working: 'Stopping...' },
        continue: { idle: 'Resume', working: 'Resuming...' },
        kill: { idle: 'Discard', working: 'Discarding...' }
    };

    function scanAction(id, action) {
        var button = null;
        var actionButtons = document.querySelectorAll('[data-action="scan-' + action + '"]');
        for (var i = 0; i < actionButtons.length; i++) {
            if (actionButtons[i].getAttribute('data-id') === id) {
                button = actionButtons[i];
                break;
            }
        }
        var labels = SCAN_ACTION_LABELS[action] || { idle: 'Retry', working: 'Working...' };
        if ((action === 'quarantine' || action === 'restore') &&
            !confirm((action === 'quarantine' ? 'Quarantine' : 'Restore') + ' all detected files from scan ' + id + '?')) {
            return;
        }
        if (button) {
            button.disabled = true;
            button.textContent = tr(labels.working);
        }
        API.post('/scan/' + encodeURIComponent(id) + '/' + action, {}).then(function(r) {
            if (r.returncode !== undefined && r.returncode !== 0 && r.returncode !== 2) {
                throw new Error(r.stderr || r.stdout || (action + ' failed'));
            }
            toast((action === 'quarantine' ? 'Files quarantined' :
                (action === 'restore' ? 'Files restored' :
                (action === 'continue' ? 'Scan resumed' :
                (action === 'kill' ? 'Scan discarded' : action + ' complete')))) + ' for scan ' + id, 'success');
            if (Router.currentPage === 'scan-management') {
                refreshScanManagementView();
            }
            else if (Router.currentPage === 'reports' &&
                (action === 'quarantine' || action === 'restore')) Router.navigate('quarantine');
            else if (Router.currentPage === 'reports') Router.navigate('reports');
        }).catch(function(e) {
            toast('Error: ' + e.message, 'error');
            if (button) {
                button.disabled = false;
                button.textContent = tr(labels.idle);
            }
        });
    }

    function resumeScan(id) {
        scanAction(id, 'continue');
    }

    function discardScan(id) {
        if (!confirm('Discard the checkpoint for scan ' + id + '? This cannot be undone and the scan will no longer be resumable.')) return;
        scanAction(id, 'kill');
    }

    function stopScan(id) {
        if (!confirm('Stop scan ' + id + '?')) return;
        scanAction(id, 'stop');
    }

    // ----- Schedules (Agendamentos) -----
    var WEEKDAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    function pad2(n) { return (n < 10 ? '0' : '') + n; }

    function humanizeSchedule(s) {
        var time = pad2(s.hour) + ':' + pad2(s.minute);
        if (s.frequency === 'weekly') {
            return tr('Weekly on') + ' ' + tr(WEEKDAY_NAMES[s.weekday] || WEEKDAY_NAMES[0]) + ' ' + tr('at') + ' ' + time;
        }
        if (s.frequency === 'custom') {
            return tr('Custom:') + ' ' + escapeHtml(s.cron_expr || '');
        }
        return tr('Daily at') + ' ' + time;
    }

    function renderSchedules() {
        return Promise.all([API.get('/schedules'), API.get('/schedules/cron')]).then(function(results) {
            var schedules = results[0].schedules || [];
            var cronFiles = results[1].files || [];
            _schedulesCache = {};
            schedules.forEach(function(s) { _schedulesCache[s.id] = s; });
            var h = '<div class="schedules-page">';

            h += '<div class="card"><div class="card-header"><span class="card-title">' + tr('Cron Jobs') +
                '</span><button class="btn btn-ghost btn-sm" data-action="refresh">🔄</button></div>';
            h += '<p class="form-help">' + tr('System-managed cron jobs installed by the installer (read-only). GUI-managed schedules are listed separately below.') + '</p>';
            h += '<div class="cron-file-list">';
            cronFiles.forEach(function(file, idx) {
                var panelId = 'cron-file-' + idx;
                h += '<div class="cron-file-item"><div class="cron-file-head"><code>' + escapeHtml(file.path) + '</code>' +
                    '<span class="cron-file-label">' + escapeHtml(tr(file.label)) + '</span>';
                if (file.exists) {
                    h += '<button type="button" class="btn btn-ghost btn-sm" data-action="cron-file-toggle" data-target="' +
                        escapeHtml(panelId) + '">' + tr('View raw file') + '</button>';
                } else {
                    h += '<span class="cron-file-missing">' + tr('File not installed') + '</span>';
                }
                h += '</div>';
                if (file.exists) {
                    h += '<pre class="cron-file-content" id="' + escapeHtml(panelId) + '" style="display:none;">' +
                        escapeHtml(file.content || '') + '</pre>';
                }
                h += '</div>';
            });
            h += '</div></div>';

            h += '<div class="card"><div class="card-header"><span class="card-title">' + tr('Scheduled Scans') +
                ' (' + schedules.length + ')</span><button class="btn btn-primary btn-sm" data-action="schedule-new">+ ' +
                tr('New Schedule') + '</button></div>';
            if (schedules.length === 0) {
                h += '<p style="padding:12px;color:var(--text-muted);">' + tr('No scheduled scans yet. Click "New Schedule" to create one.') + '</p>';
            } else {
                h += '<div class="table-scroll"><table><thead><tr><th>' + tr('Name') + '</th><th>' + tr('Path') +
                    '</th><th>' + tr('Scan type') + '</th><th>' + tr('Schedule') + '</th><th>' + tr('Status') +
                    '</th><th>' + tr('Actions') + '</th></tr></thead><tbody>';
                schedules.forEach(function(s) {
                    var typeLabel = s.scan_type === 'recent' ?
                        (tr('Recent files only') + ' (' + s.days + 'd)') : tr('Full scan (all files)');
                    h += '<tr><td>' + escapeHtml(s.name) + '</td><td style="font-size:12px;">' + escapeHtml(s.path) + '</td>' +
                        '<td>' + escapeHtml(typeLabel) + '</td><td>' + humanizeSchedule(s) + '</td>' +
                        '<td><span class="badge ' + (s.enabled ? 'badge-success' : 'badge-muted') + '">' +
                        tr(s.enabled ? 'Enabled' : 'Disabled') + '</span></td>';
                    h += '<td><button class="btn btn-ghost btn-sm" data-action="schedule-edit" data-id="' + escapeHtml(s.id) + '">' + tr('Edit') + '</button> ' +
                        '<button class="btn btn-ghost btn-sm" data-action="schedule-toggle" data-id="' + escapeHtml(s.id) + '">' +
                        tr(s.enabled ? 'Disable' : 'Enable') + '</button> ' +
                        '<button class="btn btn-ghost btn-sm" data-action="schedule-reports" data-id="' + escapeHtml(s.id) + '">' + tr('View Reports') + '</button> ' +
                        '<button class="btn btn-danger btn-sm" data-action="schedule-delete" data-id="' + escapeHtml(s.id) + '">' + tr('Delete') + '</button></td></tr>';
                });
                h += '</tbody></table></div>';
            }
            h += '</div></div>';
            return h;
        });
    }

    function toggleCronFile(button) {
        var panel = document.getElementById(button.getAttribute('data-target'));
        if (!panel) return;
        var show = panel.style.display === 'none';
        panel.style.display = show ? 'block' : 'none';
        button.textContent = tr(show ? 'Hide raw file' : 'View raw file');
    }

    function scheduleAction(id, action) {
        var schedule = _schedulesCache && _schedulesCache[id];
        if (action === 'toggle' && schedule) {
            API.put('/schedules/' + encodeURIComponent(id), Object.assign({}, schedule, { enabled: !schedule.enabled }))
                .then(function() { toast(tr('Schedule saved'), 'success'); Router.navigate('schedules'); })
                .catch(function(e) { toast('Error: ' + e.message, 'error'); });
            return;
        }
        if (action === 'delete') {
            if (!confirm(tr('Delete this schedule? Its cron entry will be removed.'))) return;
            API.del('/schedules/' + encodeURIComponent(id))
                .then(function() { toast(tr('Schedule deleted'), 'success'); Router.navigate('schedules'); })
                .catch(function(e) { toast('Error: ' + e.message, 'error'); });
        }
    }

    var _schedulesCache = {};

    function closeScheduleModal() {
        var modal = document.getElementById('schedule-modal');
        if (modal) modal.remove();
    }

    function updateScheduleFormFields() {
        var scanType = document.getElementById('sch_scan_type');
        var frequency = document.getElementById('sch_frequency');
        var daysGroup = document.getElementById('sch_days_group');
        var weekdayGroup = document.getElementById('sch_weekday_group');
        var cronGroup = document.getElementById('sch_cron_group');
        var timeGroup = document.getElementById('sch_time_group');
        if (daysGroup) daysGroup.style.display = (scanType && scanType.value === 'recent') ? 'block' : 'none';
        var freq = frequency ? frequency.value : 'daily';
        if (weekdayGroup) weekdayGroup.style.display = freq === 'weekly' ? 'block' : 'none';
        if (cronGroup) cronGroup.style.display = freq === 'custom' ? 'block' : 'none';
        if (timeGroup) timeGroup.style.display = freq === 'custom' ? 'none' : 'block';
    }

    function openScheduleModal(id) {
        closeScheduleModal();
        var existing = id ? _schedulesCache[id] : null;
        var s = existing || { name: '', path: '/home', scan_type: 'recent', days: 1, frequency: 'daily',
            hour: 3, minute: 0, weekday: 0, cron_expr: '', enabled: true };
        var modal = document.createElement('div');
        modal.id = 'schedule-modal';
        modal.className = 'modal-backdrop';
        var weekdayOptions = WEEKDAY_NAMES.map(function(name, idx) {
            return '<option value="' + idx + '"' + (idx === s.weekday ? ' selected' : '') + '>' + escapeHtml(tr(name)) + '</option>';
        }).join('');
        var h = '<div class="modal schedule-modal"><div class="modal-header"><span class="modal-title">' +
            tr(existing ? 'Edit Schedule' : 'New Schedule') + '</span><button class="modal-close" data-action="schedule-modal-close">×</button></div>';
        h += '<div class="modal-body">';
        h += '<div class="form-group"><label class="form-label">' + tr('Schedule name') + '</label>' +
            '<input type="text" class="form-input" id="sch_name" value="' + escapeHtml(s.name) + '" placeholder="' + escapeHtml(tr('Schedule name')) + '"></div>';
        h += '<div class="form-group"><label class="form-label">' + tr('Path') + '</label><div class="path-picker-row">' +
            '<input type="text" class="form-input" id="sch_path" value="' + escapeHtml(s.path) + '" placeholder="/var/www">' +
            '<button type="button" class="btn btn-ghost" data-action="folder-picker" data-target="sch_path">' + tr('Browse') + '</button></div></div>';
        h += '<div class="form-group"><label class="form-label">' + tr('Scan type') + '</label>' +
            '<select class="form-input" id="sch_scan_type"><option value="recent"' + (s.scan_type === 'recent' ? ' selected' : '') + '>' +
            tr('Recent files only') + '</option><option value="all"' + (s.scan_type === 'all' ? ' selected' : '') + '>' +
            tr('Full scan (all files)') + '</option></select></div>';
        h += '<div class="form-group" id="sch_days_group"><label class="form-label">' + tr('Modified within (days)') + '</label>' +
            '<input type="number" min="1" class="form-input" id="sch_days" value="' + escapeHtml(s.days) + '"></div>';
        h += '<div class="form-group"><label class="form-label">' + tr('Frequency') + '</label>' +
            '<select class="form-input" id="sch_frequency"><option value="daily"' + (s.frequency === 'daily' ? ' selected' : '') + '>' +
            tr('Daily') + '</option><option value="weekly"' + (s.frequency === 'weekly' ? ' selected' : '') + '>' +
            tr('Weekly') + '</option><option value="custom"' + (s.frequency === 'custom' ? ' selected' : '') + '>' +
            tr('Custom (cron expression)') + '</option></select></div>';
        h += '<div class="form-group" id="sch_time_group"><label class="form-label">' + tr('Time') + '</label>' +
            '<div class="schedule-time-row"><input type="number" min="0" max="23" class="form-input" id="sch_hour" value="' + escapeHtml(s.hour) + '" placeholder="' + tr('Hour') + '">' +
            '<input type="number" min="0" max="59" class="form-input" id="sch_minute" value="' + escapeHtml(s.minute) + '" placeholder="' + tr('Minute') + '"></div></div>';
        h += '<div class="form-group" id="sch_weekday_group"><label class="form-label">' + tr('Day of week') + '</label>' +
            '<select class="form-input" id="sch_weekday">' + weekdayOptions + '</select></div>';
        h += '<div class="form-group" id="sch_cron_group"><label class="form-label">' + tr('Custom cron expression') + '</label>' +
            '<input type="text" class="form-input" id="sch_cron_expr" value="' + escapeHtml(s.cron_expr || '') + '" placeholder="0 3 * * *">' +
            '<small class="form-help">' + tr('5 fields: minute hour day month weekday (e.g. "0 3 * * *")') + '</small></div>';
        h += '<div class="form-group"><label style="font-size:13px;"><input type="checkbox" id="sch_enabled"' +
            (s.enabled ? ' checked' : '') + '> ' + tr('Enabled (schedule will run)') + '</label></div>';
        h += '</div><div class="modal-footer"><button class="btn btn-ghost" data-action="schedule-modal-close">' + tr('Cancel') + '</button>' +
            '<button class="btn btn-primary" id="schedule-save-btn" data-action="schedule-save" data-id="' + escapeHtml(id || '') + '">' + tr('Save Schedule') + '</button></div></div>';
        modal.innerHTML = h;
        document.body.appendChild(modal);
        modal.addEventListener('click', function(e) {
            var el = e.target.closest('[data-action]');
            if (!el) return;
            var action = el.getAttribute('data-action');
            if (action === 'schedule-modal-close') closeScheduleModal();
            else if (action === 'folder-picker') openFolderPicker(el.getAttribute('data-target'), el.getAttribute('data-title'));
            else if (action === 'schedule-save') saveScheduleForm(el.getAttribute('data-id') || null);
        });
        modal.addEventListener('change', function(e) {
            if (e.target && (e.target.id === 'sch_scan_type' || e.target.id === 'sch_frequency')) updateScheduleFormFields();
        });
        updateScheduleFormFields();
    }

    function saveScheduleForm(id) {
        var name = document.getElementById('sch_name').value.trim();
        var path = document.getElementById('sch_path').value.trim();
        var scanType = document.getElementById('sch_scan_type').value;
        var days = document.getElementById('sch_days').value;
        var frequency = document.getElementById('sch_frequency').value;
        var hour = document.getElementById('sch_hour').value;
        var minute = document.getElementById('sch_minute').value;
        var weekday = document.getElementById('sch_weekday').value;
        var cronExpr = document.getElementById('sch_cron_expr').value.trim();
        var enabled = document.getElementById('sch_enabled').checked;
        if (!name) { toast('Enter a schedule name', 'error'); return; }
        if (!path) { toast('Enter a scan path', 'error'); return; }
        var payload = {
            name: name, path: path, scan_type: scanType, days: parseInt(days, 10) || 1,
            frequency: frequency, hour: parseInt(hour, 10) || 0, minute: parseInt(minute, 10) || 0,
            weekday: parseInt(weekday, 10) || 0, cron_expr: cronExpr, enabled: enabled,
        };
        var button = document.getElementById('schedule-save-btn');
        if (button) { button.disabled = true; button.textContent = tr('Saving...'); }
        var request = id ? API.put('/schedules/' + encodeURIComponent(id), payload) : API.post('/schedules', payload);
        request.then(function() {
            toast(tr('Schedule saved'), 'success');
            closeScheduleModal();
            Router.navigate('schedules');
        }).catch(function(e) {
            toast('Error: ' + e.message, 'error');
            if (button) { button.disabled = false; button.textContent = tr('Save Schedule'); }
        });
    }

    function closeScheduleReports() {
        var modal = document.getElementById('schedule-reports-modal');
        if (modal) modal.remove();
    }

    function openScheduleReports(id) {
        var old = document.getElementById('schedule-reports-modal');
        if (old) old.remove();
        var modal = document.createElement('div');
        modal.id = 'schedule-reports-modal';
        modal.className = 'modal-backdrop';
        modal.innerHTML = '<div class="modal report-details-modal"><div class="modal-header"><span class="modal-title">' +
            tr('Reports for') + '</span><button class="modal-close" data-action="schedule-reports-close">×</button></div>' +
            '<div class="modal-body"><div class="loading">' + tr('Loading...') + '</div></div>' +
            '<div class="modal-footer"><button class="btn btn-ghost" data-action="schedule-reports-close">' + tr('Close') + '</button></div></div>';
        document.body.appendChild(modal);
        modal.addEventListener('click', function(e) {
            var el = e.target.closest('[data-action]');
            if (!el) return;
            var action = el.getAttribute('data-action');
            if (action === 'schedule-reports-close') closeScheduleReports();
            else if (action === 'report-details') openReportDetails(el.getAttribute('data-id'));
        });
        API.get('/schedules/' + encodeURIComponent(id) + '/reports').then(function(data) {
            var body = modal.querySelector('.modal-body');
            if (!body) return;
            var title = modal.querySelector('.modal-title');
            if (title) title.textContent = tr('Reports for') + ' ' + (data.schedule ? data.schedule.name : id);
            var reports = data.reports || [];
            if (!reports.length) {
                body.innerHTML = '<p style="color:var(--text-muted);">' + tr('No reports found yet for this schedule.') + '</p>';
                return;
            }
            var h = '<table><thead><tr><th>' + tr('Scan ID') + '</th><th>' + tr('Started') + '</th><th>' +
                tr('Files') + '</th><th>' + tr('Hits') + '</th><th>' + tr('Actions') + '</th></tr></thead><tbody>';
            reports.forEach(function(r) {
                var scanId = String(r.scan_id || '');
                h += '<tr><td><code>' + escapeHtml(scanId) + '</code></td><td>' + fmtTime(r.started_epoch) + '</td>' +
                    '<td>' + (Number(r.total_files) || 0) + '</td><td>' + (Number(r.total_hits) || 0) + '</td>' +
                    '<td><button class="btn btn-primary btn-sm" data-action="report-details" data-id="' + escapeHtml(scanId) + '">' + tr('Show Report') + '</button></td></tr>';
            });
            h += '</tbody></table>';
            body.innerHTML = h;
        }).catch(function(err) {
            var body = modal.querySelector('.modal-body');
            if (body) body.innerHTML = '<p style="color:var(--danger);">' + escapeHtml(err.message) + '</p>';
        });
    }

    // ----- Monitoring -----
    function renderMonitoring() {
        return Promise.all([
            API.get('/system'), API.get('/monitor/users'),
            // Web server detection is best-effort; never block the page.
            API.get('/monitor/webserver').catch(function() { return {}; }),
            // Mail folder detection is best-effort; never block the page.
            API.get('/monitor/mail').catch(function() { return {}; }),
            API.get('/monitor/activity?lines=40').catch(function() { return {}; }),
            API.get('/monitor/scope'),
            // Best-effort: an unreadable file must not break the page, and the
            // card hides its controls so an empty list can never be saved.
            API.get('/monitor/paths').catch(function(err) {
                return { error: (err && err.message) || String(err) };
            })
        ]).then(function(results) {
            var data = results[0], userData = results[1], ws = results[2] || {},
                mail = results[3] || {}, act = results[4] || {},
                scope = results[5], extra = results[6] || {};
            var sys = data.system;
            var h = '<div class="monitor-grid">';
            h += '<div class="card monitor-status-card"><div class="card-header"><span class="card-title">' + tr('Real-time monitoring (inotify)') + '</span><span class="monitor-badge">' + tr('Inotify') + '</span></div>';
            if (!sys.is_root) {
                h += '<div class="alert alert-warning"><strong>' + tr('Warning:') + '</strong> ' + tr('the GUI is not running with root privileges.') + ' ' +
                    tr('Inotify monitoring usually requires root (the maldet config and state directories are root-only).') + ' ' +
                    tr('Start the GUI as root to enable the monitor.') + '</div>';
            }
            h += '<div class="monitor-status-row"><span>' + tr('Monitoring status') + '</span><strong class="monitor-state ' +
                (sys.monitor_running ? 'is-running' : 'is-stopped') + '">' + tr(sys.monitor_running ? 'RUNNING' : 'STOPPED') + '</strong></div>';
            h += '<div class="monitor-actions"><button class="btn btn-primary" data-action="monitor-start">' + tr('Start') + '</button> ';
            h += '<button class="btn btn-danger" data-action="monitor-stop">' + tr('Stop') + '</button> ';
            h += '<button class="btn btn-warning" data-action="monitor-reload">' + tr('Reload') + '</button></div></div>';
            h += '<div class="card monitor-users-card"><div class="card-header"><span class="card-title">' + tr('Users monitored') + '</span></div>';
            h += '<p>' + tr('Select the users whose home directories should be monitored. Changes take effect after Reload.') + '</p>';
            h += '<div class="user-monitor-list">';
            if (!(userData.users || []).length) h += '<p class="form-help">' + tr('No eligible home users found.') + '</p>';
            (userData.users || []).forEach(function(user) {
                h += '<label class="checkbox-row"><input type="checkbox" class="monitor-user-toggle" data-user="' +
                    escapeHtml(user.name) + '"' + (user.enabled ? ' checked' : '') + '> ' +
                    '<strong>' + escapeHtml(user.name) + '</strong> <span class="muted">(' +
                    escapeHtml(user.home) + ')</span></label>';
            });
            h += '</div><button class="btn btn-primary" data-action="monitor-save-users">' + tr('Save user selection') + '</button></div></div>';
            h += '<div class="card monitor-scope-card"><div class="card-header"><span class="card-title">' +
                tr('User directory scope') + '</span></div>';
            h += '<select class="form-input" id="monitor-scope">';
            [['recursive', 'All folders of each user (recursive)'],
                ['webroots', 'Only public_html and htdocs of each user'],
                ['custom', 'Other paths configured manually']].forEach(function(option) {
                if (option[0] === 'custom' && scope.scope !== 'custom') return;
                h += '<option value="' + option[0] + '"' + (scope.scope === option[0] ? ' selected' : '') +
                    (option[0] === 'custom' ? ' disabled' : '') + '>' + tr(option[1]) + '</option>';
            });
            h += '</select><p class="form-help">' +
                tr('In webroot-only mode, additional document roots and temporary folders are not watched. Reload to apply changes.') +
                '</p><button class="btn btn-primary" data-action="monitor-save-scope">' +
                tr('Save monitoring scope') + '</button></div>';
            // ---- Web server detection card (monitor public_html or not) ----
            h += '<div class="card monitor-webserver-card"><div class="card-header"><span class="card-title">' + tr('Web server detection') + '</span><span class="monitor-badge">' + tr('public_html') + '</span></div>';
            if (!ws || typeof ws.detected === 'undefined') {
                h += '<p class="form-help">' + tr('Web server detection is unavailable.') + '</p>';
            } else if (!ws.detected) {
                h += '<p>' + tr('No running web server detected.') + '</p>';
            } else {
                h += '<div class="monitor-status-row"><span>' + tr('Detected web server:') + '</span><strong>' + escapeHtml(ws.servers.join(', ')) + '</strong></div>';
                h += '<p>' + tr('Document roots detected:') + '</p><ul class="webserver-docroot-list">';
                if (!(ws.docroots || []).length) {
                    h += '<li class="form-help">' + tr('No document roots found in the server configuration.') + '</li>';
                } else {
                    ws.docroots.forEach(function(dr) {
                        h += '<li>' + escapeHtml(dr) + '</li>';
                    });
                }
                h += '</ul>';
                h += '<label class="checkbox-row"><input type="checkbox" id="monitor-docroot-toggle"' +
                    (ws.autodetect === '1' ? ' checked' : '') +
                    (scope.scope === 'webroots' ? ' disabled' : '') + '> ' +
                    tr('Monitor detected document roots (e.g. public_html)') + '</label>';
                if (scope.scope === 'webroots') {
                    h += '<p class="form-help">' +
                        tr('In webroot-only mode, additional document roots and temporary folders are not watched. Reload to apply changes.') +
                        '</p>';
                }
                h += '<p class="form-help">' + tr('Changes take effect after Reload or restarting the monitor.') + '</p>';
                h += '<button class="btn btn-primary" data-action="monitor-save-webserver"' +
                    (scope.scope === 'webroots' ? ' disabled' : '') + '>' + tr('Save') + '</button>';
            }
            h += '</div></div>';
            // ---- Email folder detection card ----
            h += '<div class="card monitor-mail-card"><div class="card-header"><span class="card-title">' + tr('Email folder detection') + '</span><span class="monitor-badge">' + tr('maildirs') + '</span></div>';
            if (!mail || typeof mail.detected === 'undefined') {
                h += '<p class="form-help">' + tr('Email folder detection is unavailable.') + '</p>';
            } else if (!mail.detected) {
                h += '<p>' + tr('No running mail server detected.') + '</p>';
            } else {
                h += '<div class="monitor-status-row"><span>' + tr('Detected mail server:') + '</span><strong>' + escapeHtml(mail.servers.join(', ')) + '</strong></div>';
                h += '<p>' + tr('Email folders detected:') + '</p><ul class="webserver-docroot-list">';
                if (!(mail.maildirs || []).length) {
                    h += '<li class="form-help">' + tr('No email folders found on this host.') + '</li>';
                } else {
                    mail.maildirs.forEach(function(md) {
                        h += '<li>' + escapeHtml(md) + '</li>';
                    });
                }
                h += '</ul>';
                h += '<label class="checkbox-row"><input type="checkbox" id="monitor-maildir-toggle"' +
                    (mail.autodetect === '1' ? ' checked' : '') +
                    (scope.scope === 'webroots' ? ' disabled' : '') + '> ' +
                    tr('Monitor detected email folders (e.g. /var/mail, /var/vmail)') + '</label>';
                if (scope.scope === 'webroots') {
                    h += '<p class="form-help">' +
                        tr('In webroot-only mode, additional document roots and temporary folders are not watched. Reload to apply changes.') +
                        '</p>';
                }
                h += '<p class="form-help">' + tr('Changes take effect after Reload or restarting the monitor.') + '</p>';
                h += '<button class="btn btn-primary" data-action="monitor-save-mail"' +
                    (scope.scope === 'webroots' ? ' disabled' : '') + '>' + tr('Save') + '</button>';
            }
            h += '</div></div>';
            // ---- Monitored folders card (extra paths added to the watch list) ----
            h += '<div class="card monitor-paths-card"><div class="card-header"><span class="card-title">' + tr('Monitored folders') + '</span></div>';
            if (extra.error) {
                // Never render an empty list after a read failure: saving it
                // would overwrite the existing entries with nothing.
                h += '<div class="alert alert-warning"><strong>' + tr('Warning:') + '</strong> ' +
                    escapeHtml(extra.error) + '</div>';
            } else {
                h += '<p class="form-help">' +
                    tr('These folders are added to the monitored paths (monitor_paths.extra). Absolute paths must exist on the server. Changes take effect after Reload.') +
                    '</p>';
                if (scope.scope === 'webroots') {
                    h += '<p class="form-help">' +
                        tr('In webroot-only mode, additional document roots and temporary folders are not watched. Reload to apply changes.') +
                        '</p>';
                }
                h += '<div class="monitor-path-add"><input type="text" class="form-input" id="monitor-path-input" placeholder="/var/www/html" aria-label="' +
                    tr('Folder path (e.g. /var/www/html)') + '"><button type="button" class="btn btn-ghost" data-action="folder-picker" data-target="monitor-path-input" data-title="Choose folder">' +
                    tr('Browse') + '</button><button class="btn btn-primary" data-action="monitor-add-path">' +
                    tr('Add folder') + '</button></div>';
                h += '<div class="monitor-path-list" id="monitor-path-list">' + renderMonitorPathList(extra.paths) + '</div>';
                h += '<button class="btn btn-primary" data-action="monitor-save-paths">' + tr('Save folders') + '</button>';
            }
            h += '</div>';
            // ---- Monitor activity card (real-time scanned/changed files) ----
            h += '<div class="card monitor-activity-card"><div class="card-header"><span class="card-title">' + tr('Monitor activity') + '</span>' +
                '<span class="monitor-badge">' + (act.running ? tr('Live') : tr('STOPPED')) + '</span></div>';
            h += '<p class="form-help">' + tr('Files detected by inotify (create/move/modify) in real time, newest first. These are queued for the monitor scan batches.') + '</p>';
            h += '<div class="monitor-activity-list" id="monitor-activity-body">' + renderMonitorActivityList(act) + '</div>';
            h += '</div></div>';
            return h;
        });
    }

    function renderMonitorActivityList(act) {
        var entries = act && act.entries || [];
        if (!entries.length) {
            if (act && act.running) {
                return '<p class="form-help">' + tr('No monitored file activity yet. New, moved or modified files will appear here as the monitor detects them.') + '</p>';
            }
            return '<p class="form-help">' + tr('Monitor is stopped — no live activity. Start the monitor to watch files in real time.') + '</p>';
        }
        var rows = '';
        entries.forEach(function(entry) {
            var ev = entry.event || '-';
            var evClass = ev.indexOf('CREATE') !== -1 ? 'ev-create' :
                (ev.indexOf('MOVE') !== -1 ? 'ev-move' : 'ev-modify');
            rows += '<div class="monitor-activity-row"><span class="monitor-activity-event ' + evClass + '">' +
                escapeHtml(ev) + '</span><span class="monitor-activity-file" title="' +
                escapeHtml(entry.file) + '">' + escapeHtml(entry.file) + '</span>' +
                (entry.time ? '<span class="monitor-activity-time">' + escapeHtml(entry.time) + '</span>' : '') +
                '</div>';
        });
        if (act.total_events !== undefined && act.total_events !== null) {
            rows += '<div class="monitor-activity-total form-help">' + escapeHtml(String(act.total_events)) + ' ' + tr('events logged') + '</div>';
        }
        return rows;
    }

    var _monitorExtraPaths = [];
    function renderMonitorPathList(paths) {
        if (paths) _monitorExtraPaths = paths.slice();
        if (!_monitorExtraPaths.length) {
            return '<p class="form-help">' +
                tr('No extra folders configured. Use the field above to add folders to real-time monitoring.') + '</p>';
        }
        var rows = '';
        _monitorExtraPaths.forEach(function(path) {
            rows += '<div class="monitor-path-row"><code class="monitor-path-value">' + escapeHtml(path) + '</code>' +
                '<button class="btn btn-danger btn-sm" data-action="monitor-remove-path" data-path="' +
                escapeHtml(path) + '">' + tr('Remove') + '</button></div>';
        });
        return rows;
    }
    function addMonitorPath() {
        var input = document.getElementById('monitor-path-input');
        if (!input) return;
        var value = (input.value || '').trim();
        if (!value) { toast(tr('Enter a folder path to add.'), 'error'); return; }
        if (value.charAt(0) !== '/') { toast(tr('Absolute path required (e.g. /var/www).'), 'error'); return; }
        if (value.length > 1) value = value.replace(/\/+$/, '') || '/';
        if (_monitorExtraPaths.indexOf(value) !== -1) {
            toast(tr('Folder already in the list.'), 'info');
            return;
        }
        _monitorExtraPaths.push(value);
        input.value = '';
        input.focus();
        var list = document.getElementById('monitor-path-list');
        if (list) list.innerHTML = renderMonitorPathList();
    }
    function removeMonitorPath(path) {
        _monitorExtraPaths = _monitorExtraPaths.filter(function(item) { return item !== path; });
        var list = document.getElementById('monitor-path-list');
        if (list) list.innerHTML = renderMonitorPathList();
    }
    function saveMonitorPaths() {
        API.put('/monitor/paths', { paths: _monitorExtraPaths }).then(function(data) {
            toast((data && data.message) || tr('Monitored folders saved'), 'success');
            Router.navigate('monitoring');
        }).catch(function(e) { toast('Error: ' + e.message, 'error'); });
    }

    var _monitorActivityTimer = null;
    function startMonitorActivityRefresh() {
        stopMonitorActivityRefresh();
        _monitorActivityTimer = setInterval(function() {
            if (Router.currentPage !== 'monitoring') { stopMonitorActivityRefresh(); return; }
            var body = document.getElementById('monitor-activity-body');
            if (!body) return;
            API.get('/monitor/activity?lines=40').then(function(act) {
                var el = document.getElementById('monitor-activity-body');
                if (el) el.innerHTML = renderMonitorActivityList(act);
            }).catch(function() { /* best-effort */ });
        }, 3000);
    }
    function stopMonitorActivityRefresh() {
        if (_monitorActivityTimer) {
            clearInterval(_monitorActivityTimer);
            _monitorActivityTimer = null;
        }
    }

    function clearMonitorPollers() {
        // Cancel any in-flight monitor polling timers (start/stop).
        var t;
        while ((t = _monitorPollTimers.pop()) !== undefined) {
            clearInterval(t);
        }
    }
    var _monitorPollTimers = [];
    function monitorStart() {
        API.post('/monitor', { action: 'start', mode: 'users' }).then(function(data) {
            if (data.status === 'stopping' || data.status === 'starting') {
                // Systemd start/stop runs in the background; poll the real state.
                if (data.status === 'stopping') { clearMonitorPollers(); }
                toast(data.status === 'stopping'
                    ? 'Stopping monitor... (may take up to 2 minutes)'
                    : 'Starting monitor...', 'info', 6000);
                if (data.status === 'starting') pollMonitorStarted();
                else pollMonitorStopped();
                return;
            }
            if (data && data.message === 'Monitor is already running') {
                toast('Monitor is already running', 'info');
                Router.navigate('monitoring');
                return;
            }
            toast('Monitor started', 'success');
            Router.navigate('monitoring');
        })
        .catch(function(e) { toast('Error: ' + e.message, 'error'); });
    }
    function monitorStop() {
        clearMonitorPollers();
        API.post('/monitor', { action: 'stop' }).then(function(data) {
            toast('Stopping monitor... (may take up to 2 minutes)', 'info', 6000);
            pollMonitorStopped();
        })
        .catch(function(e) { toast('Error: ' + e.message, 'error'); });
    }
    function monitorReload() {
        API.post('/monitor', { action: 'reload' }).then(function(data) {
            toast((data && data.message) || 'Monitor reloaded', 'success');
            updateStatusIndicator();
            Router.navigate('monitoring');
            // Reloading systemd can briefly leave the old status in the page;
            // fetch the post-restart state again after the unit settles.
            setTimeout(function() {
                if (Router.currentPage === 'monitoring') {
                    updateStatusIndicator();
                    Router.navigate('monitoring');
                }
            }, 1000);
        })
        .catch(function(e) { toast('Error: ' + e.message, 'error'); });
    }
    function saveMonitorUsers() {
        var disabled = [];
        document.querySelectorAll('.monitor-user-toggle').forEach(function(input) {
            if (!input.checked) disabled.push(input.getAttribute('data-user'));
        });
        API.put('/monitor/users', { users: disabled }).then(function(data) {
            toast((data && data.message) || 'User selection saved; reload the monitor', 'success');
        }).catch(function(e) { toast('Error: ' + e.message, 'error'); });
    }
    function saveMonitorScope() {
        var select = document.getElementById('monitor-scope');
        if (!select || select.value === 'custom') return;
        API.put('/monitor/scope', { scope: select.value }).then(function(data) {
            toast((data && data.message) || tr('Monitor scope saved'), 'success');
            Router.navigate('monitoring');
        }).catch(function(e) { toast('Error: ' + e.message, 'error'); });
    }
    function saveMonitorWebserver() {
        var toggle = document.getElementById('monitor-docroot-toggle');
        if (!toggle || toggle.disabled) return;
        API.post('/monitor/webserver', { enabled: !!toggle.checked }).then(function(data) {
            toast((data && data.message) || 'Web server monitoring updated', 'success');
        }).catch(function(e) { toast('Error: ' + e.message, 'error'); });
    }
    function saveMonitorMail() {
        var toggle = document.getElementById('monitor-maildir-toggle');
        if (!toggle || toggle.disabled) return;
        API.post('/monitor/mail', { enabled: !!toggle.checked }).then(function(data) {
            toast((data && data.message) || tr('Email folder monitoring updated'), 'success');
        }).catch(function(e) { toast('Error: ' + e.message, 'error'); });
    }
    function pollMonitorStarted() {
        // Poll system status until the monitor is fully up (max ~90s).
        var tries = 0;
        var timer = setInterval(function() {
            tries++;
            API.get('/system').then(function(data) {
                var running = data.system && data.system.monitor_running;
                if (running) {
                    clearInterval(timer);
                    updateStatusIndicator();
                    toast('Monitor started', 'success');
                    Router.navigate('monitoring');
                } else if (tries > 45) {
                    clearInterval(timer);
                    updateStatusIndicator();
                    toast('Timed out waiting for the monitor to start', 'error');
                    Router.navigate('monitoring');
                }
            }).catch(function() {
                // keep polling on transient errors
            });
        }, 2000);
        _monitorPollTimers.push(timer);
    }
    function pollMonitorStopped() {
        // Poll system status until the monitor is fully down (max ~130s).
        var tries = 0;
        var timer = setInterval(function() {
            tries++;
            API.get('/system').then(function(data) {
                var running = data.system && data.system.monitor_running;
                if (!running) {
                    clearInterval(timer);
                    updateStatusIndicator();
                    toast('Monitor stopped', 'success');
                    Router.navigate('monitoring');
                    setTimeout(function() {
                        if (Router.currentPage === 'monitoring') {
                            updateStatusIndicator();
                            Router.navigate('monitoring');
                        }
                    }, 500);
                } else if (tries > 65) {
                    clearInterval(timer);
                    updateStatusIndicator();
                    toast('Timed out waiting for the monitor to stop', 'error');
                    Router.navigate('monitoring');
                }
            }).catch(function() {
                // keep polling on transient errors
            });
        }, 2000);
        _monitorPollTimers.push(timer);
    }

    // ----- Updates -----
    var _lastUpdateDetails = null;

    function renderUpdates() {
        return API.get('/system').then(function(data) {
            var sys = data.system;
            var h = '<div class="card"><div class="card-header"><span class="card-title">Updates</span></div><table>';
            h += '<tr><td>LMD Version</td><td>' + escapeHtml(sys.version || trUpdate('unknown')) + '</td>';
            h += '<td><button class="btn btn-primary btn-sm" data-action="update-ver">Update</button> <button class="btn btn-warning btn-sm" data-action="update-ver-beta">Beta</button></td></tr>';
            h += '<tr><td>ClamAV</td><td>' + escapeHtml(sys.clamav_version || trUpdate('unknown')) + ' (' + escapeHtml(trUpdate(sys.clamav_status || 'missing')) + ')</td>';
            h += '<td><button class="btn btn-primary btn-sm" data-action="update-clamav">' + tr('Update ClamAV') + '</button></td></tr>';
            h += '<tr><td>Signatures</td><td>' + escapeHtml(sys.signature_version || trUpdate('unknown')) + '</td>';
            h += '<td><button class="btn btn-primary btn-sm" data-action="update-sigs">Update Sigs</button></td></tr>';
            h += '</table></div>';
            h += '<div class="card"><div class="card-header"><span class="card-title">Installer location</span></div>';
            h += '<p><strong>Installation directory:</strong> <code>' +
                escapeHtml(sys.base_dir || trUpdate('unknown')) + '</code></p>';
            h += '<p><strong>Installer directory:</strong> <code>' +
                escapeHtml(sys.installer_directory || tr('Not available in the installed runtime')) + '</code></p>';
            if (sys.installer_path) {
                h += '<p><strong>Installer:</strong> <code>' + escapeHtml(sys.installer_path) + '</code></p>';
            }
            h += '</div>';
            if (_lastUpdateDetails) {
                var d = _lastUpdateDetails;
                var output = (d.stdout || '') + (d.stderr ? '\n' + d.stderr : '');
                h += '<div class="card"><div class="card-header"><span class="card-title">Update details</span></div>';
                var status = d.status || (d.returncode === 0 ? 'completed' : 'failed');
                var statusColor = status === 'completed' ? 'var(--success)' : 'var(--danger)';
                h += '<p><strong>Status:</strong> <span style="color:' + statusColor + ';">' +
                    escapeHtml(trUpdate(status)) + '</span></p>';
                h += '<p><strong>Operation:</strong> ' + escapeHtml(trUpdate(d.operation || 'Update')) + '</p>';
                h += '<p><span>Before:</span> <code>' + escapeHtml(updateValue(d.before)) + '</code> &nbsp; <span>After:</span> <code>' +
                    escapeHtml(updateValue(d.after)) + '</code> &nbsp; <span>Changed:</span> <strong>' +
                    trUpdate(d.changed ? 'yes' : 'no') + '</strong></p>';
                h += '<details><summary>Command output</summary><pre class="report-json">' +
                    escapeHtml(output || 'No output returned by maldet.') + '</pre></details></div>';
            }
            return h;
        });
    }

    function updateValue(value) {
        if (!value) return trUpdate('unknown');
        var keys = Object.keys(value);
        return keys.length && value[keys[0]] ? String(value[keys[0]]) : trUpdate('unknown');
    }

    // Update-page values use an "update:" key prefix so generic words (yes/no,
    // completed/failed) are not rewritten on other pages by translateDom.
    function trUpdate(value) {
        var key = 'update:' + value, text = tr(key);
        return text === key ? value : text;
    }

    function updateErrorMessage(err) {
        // Failed updates return the full payload (no "error" field); point to the details card.
        return err.data && err.data.operation ? tr('see the update details below') : tr(err.message);
    }

    function updateVer(beta) {
        API.post('/update/version', { beta: beta }).then(function(data) {
            _lastUpdateDetails = data;
            toast(tr(data.changed ? 'Update complete: version changed' : 'Update complete: already current'), 'success');
            Router.navigate('updates');
        }).catch(function(err) {
            if (err.data) _lastUpdateDetails = err.data;
            toast(tr('Update failed: ') + updateErrorMessage(err), 'error');
            Router.navigate('updates');
        });
    }
    function updateSigs() {
        API.post('/update/sigs', {}).then(function(data) {
            _lastUpdateDetails = data;
            toast(tr(data.changed ? 'Signatures updated' : 'Signatures already current'), 'success');
            Router.navigate('updates');
        }).catch(function(err) {
            if (err.data) _lastUpdateDetails = err.data;
            toast(tr('Signature update failed: ') + updateErrorMessage(err), 'error');
            Router.navigate('updates');
        });
    }
    function updateClamAv() {
        API.post('/update/clamav', {}).then(function(data) {
            _lastUpdateDetails = data;
            toast(data.changed ? tr('ClamAV updated') : tr('ClamAV already current'), 'success');
            Router.navigate('updates');
        }).catch(function(err) {
            if (err.data) _lastUpdateDetails = err.data;
            toast(tr('ClamAV update failed: ') + updateErrorMessage(err), 'error');
            Router.navigate('updates');
        });
    }

    // ----- Config -----
    var CONFIG_SECTION_ICONS = {
        'E-mail': '📧', 'Telegram': '📨', 'General Options': '⚙️',
        'SCAN OPTIONS': '🔍', 'QUARANTINE OPTIONS': '📦', 'MONITORING OPTIONS': '👁️',
        'STATISTICAL ELK COLLECT': '📊', 'SESSION FORMAT': '🗂️',
        'STATISTICAL ANALYSIS': '📈', 'SCAN PROGRESS LOGGING': '📝', 'POST-SCAN HOOKS': '🪝'
    };
    var CONFIG_LABEL_ACRONYMS = {
        smtp: 'SMTP', elk: 'ELK', ssh: 'SSH', ftp: 'FTP', ip: 'IP', id: 'ID',
        url: 'URL', html: 'HTML', tsv: 'TSV', pid: 'PID', uid: 'UID', gid: 'GID',
        cpu: 'CPU', io: 'IO', tls: 'TLS', ssl: 'SSL'
    };

    function humanizeConfigLabel(key) {
        return key.split('_').map(function(word) {
            var lower = word.toLowerCase();
            if (CONFIG_LABEL_ACRONYMS[lower]) return CONFIG_LABEL_ACRONYMS[lower];
            return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
        }).join(' ');
    }

    function isBooleanConfigOption(opt) {
        var value = (opt.value || '').trim();
        if (value !== '0' && value !== '1') return false;
        var tip = (opt.comment || '').toLowerCase();
        return /\b0\s*=\s*disabled\b/.test(tip) && /\b1\s*=\s*enabled\b/.test(tip);
    }

    function configFieldHtml(key, opt) {
        var label = humanizeConfigLabel(key);
        var tipId = 'config-tip-' + key.replace(/[^a-z0-9_-]/gi, '');
        var searchText = (label + ' ' + key + ' ' + (opt.comment || '')).toLowerCase();
        var h = '<div class="config-option" data-key="' + escapeHtml(key) + '" data-search="' + escapeHtml(searchText) + '">';
        h += '<div class="config-option-head"><div><label class="config-option-label" for="config-' +
            escapeHtml(key) + '">' + escapeHtml(label) + '</label>' +
            '<code class="config-option-key">' + escapeHtml(key) + '</code></div>';
        if (opt.comment) {
            h += '<button type="button" class="config-tip-btn" data-action="config-tip-toggle" data-tip="' +
                escapeHtml(tipId) + '" title="' + escapeHtml(tr('Show tip')) + '">i</button>';
        }
        h += '</div>';
        if (isBooleanConfigOption(opt)) {
            var isEnabled = opt.value === '1';
            h += '<div class="config-toggle"><label class="config-toggle-switch"><input type="checkbox" id="config-' +
                escapeHtml(key) + '" data-key="' + escapeHtml(key) + '" data-bool="1"' + (isEnabled ? ' checked' : '') +
                '><span class="config-toggle-slider"></span></label>' +
                '<span class="config-toggle-state">' + tr(isEnabled ? 'Enabled' : 'Disabled') + '</span></div>';
        } else {
            h += '<input id="config-' + escapeHtml(key) + '" type="text" class="form-input" value="' +
                escapeHtml(opt.value) + '" data-key="' + escapeHtml(key) + '">';
        }
        if (opt.comment) {
            h += '<div class="config-tip" id="' + escapeHtml(tipId) + '">' + escapeHtml(opt.comment) + '</div>';
        }
        return h + '</div>';
    }

    function renderConfig() {
        return API.get('/config').then(function(data) {
            var config = data.config || {};
            var groups = {};
            var groupOrder = [];
            for (var key in config) {
                var opt = config[key];
                if (key === '__error__') continue;
                var group = opt.section || 'General';
                if (key.indexOf('email_') === 0) group = 'E-mail';
                else if (key.indexOf('telegram_') === 0) group = 'Telegram';
                if (!groups[group]) {
                    groups[group] = [];
                    groupOrder.push(group);
                }
                groups[group].push({ key: key, opt: opt });
            }
            var h = '<div class="config-page"><div class="card config-intro"><div class="card-header"><span class="card-title">' +
                tr('Configuration') + '</span></div>';
            h += '<p class="config-path">' + tr('File') + ': <code>' + escapeHtml(data.path) + '</code></p>';
            h += '<p class="form-help">' +
                tr('Edit values below and save only the settings you changed. Click the tip icon (i) next to a field for details.') +
                '</p>';
            h += '<div class="config-toolbar"><input type="search" id="config-search" class="form-input config-search" placeholder="' +
                escapeHtml(tr('Search settings...')) + '">';
            h += '<div class="config-toolbar-btns"><button type="button" class="btn btn-ghost btn-sm" data-action="config-expand-all">' +
                tr('Expand all') + '</button><button type="button" class="btn btn-ghost btn-sm" data-action="config-collapse-all">' +
                tr('Collapse all') + '</button></div></div></div>';
            groupOrder.forEach(function(group, idx) {
                var icon = CONFIG_SECTION_ICONS[group] || '🔧';
                h += '<div class="card config-section' + (idx === 0 ? ' is-open' : '') + '">';
                h += '<div class="config-section-header" data-action="config-toggle-section">' +
                    '<span class="config-section-icon">' + icon + '</span>' +
                    '<h3 class="config-section-title">' + escapeHtml(tr(group)) +
                    ' <span class="config-section-count">(' + groups[group].length + ')</span></h3>' +
                    '<span class="config-section-caret">▶</span></div>';
                h += '<div class="config-options">';
                groups[group].forEach(function(item) {
                    h += configFieldHtml(item.key, item.opt);
                });
                h += '</div></div>';
            });
            h += '<div class="config-save-bar"><span class="config-changed-badge" id="config-changed-badge">' +
                tr('No changes') + '</span><button class="btn btn-success" id="save-config-btn" data-action="save-config">' +
                tr('Save Changes') + '</button></div></div>';
            return h;
        });
    }

    function toggleConfigSection(headerEl) {
        var section = headerEl.closest('.config-section');
        if (section) section.classList.toggle('is-open');
    }

    function setAllConfigSections(open) {
        document.querySelectorAll('#content .config-section').forEach(function(section) {
            section.classList.toggle('is-open', open);
        });
    }

    function toggleConfigTip(button) {
        var tip = document.getElementById(button.dataset.tip);
        if (!tip) return;
        var isOpen = tip.classList.toggle('is-open');
        button.classList.toggle('is-active', isOpen);
    }

    function filterConfigOptions(term) {
        term = (term || '').trim().toLowerCase();
        document.querySelectorAll('#content .config-option').forEach(function(opt) {
            var match = !term || (opt.dataset.search || '').indexOf(term) !== -1;
            opt.classList.toggle('is-hidden', !match);
        });
        document.querySelectorAll('#content .config-section').forEach(function(section) {
            var visible = section.querySelectorAll('.config-option:not(.is-hidden)').length;
            section.style.display = (term && visible === 0) ? 'none' : '';
            if (term && visible > 0) section.classList.add('is-open');
        });
    }

    function updateConfigFieldState(input) {
        var wrap = input.closest('.config-option');
        if (!wrap) return;
        var modified = input.type === 'checkbox' ?
            (input.checked !== input.defaultChecked) : (input.value !== input.defaultValue);
        wrap.classList.toggle('is-modified', modified);
        if (input.type === 'checkbox') {
            var state = wrap.querySelector('.config-toggle-state');
            if (state) state.textContent = tr(input.checked ? 'Enabled' : 'Disabled');
        }
        updateConfigChangedBadge();
    }

    function updateConfigChangedBadge() {
        var badge = document.getElementById('config-changed-badge');
        if (!badge) return;
        var count = document.querySelectorAll('#content .config-option.is-modified').length;
        if (count > 0) {
            badge.textContent = count + ' ' + tr('unsaved change(s)');
            badge.classList.add('has-changes');
        } else {
            badge.textContent = tr('No changes');
            badge.classList.remove('has-changes');
        }
    }

    function changePassword() {
        var current = document.getElementById('current-password');
        var next = document.getElementById('new-password');
        var confirm = document.getElementById('confirm-password');
        if (!current || !next || !confirm) return;
        if (next.value.length < 8) {
            toast('New password must contain at least 8 characters', 'error');
            return;
        }
        if (next.value !== confirm.value) {
            toast('New passwords do not match', 'error');
            return;
        }
        var button = document.querySelector('[data-action="change-password"]');
        if (button) button.disabled = true;
        API.post('/auth/change', {
            current_password: current.value,
            new_password: next.value,
            confirm_password: confirm.value
        }).then(function() {
            current.value = '';
            next.value = '';
            confirm.value = '';
            toast('Password changed successfully', 'success');
        }).catch(function(err) {
            toast('Password change failed: ' + err.message, 'error');
        }).then(function() {
            if (button) button.disabled = false;
        });
    }

    function securityChangePassword() {
        var msg = document.getElementById('security-message');
        var current = document.getElementById('sec-current-password');
        var next = document.getElementById('sec-new-password');
        var confirm = document.getElementById('sec-confirm-password');
        if (!current || !next || !confirm) {
            changePassword();
            return;
        }
        if (!current.value || !next.value || !confirm.value) {
            if (msg) msg.textContent = 'Please fill in all password fields.';
            toast('Please fill in all password fields.', 'error');
            return;
        }
        if (next.value.length < 8) {
            if (msg) msg.textContent = 'New password must contain at least 8 characters.';
            toast('New password must contain at least 8 characters.', 'error');
            return;
        }
        if (next.value !== confirm.value) {
            if (msg) msg.textContent = 'New passwords do not match.';
            toast('New passwords do not match.', 'error');
            return;
        }
        var button = document.querySelector('[data-action="security-change-password"]');
        if (button) button.disabled = true;
        API.post('/auth/change', {
            current_password: current.value,
            new_password: next.value,
            confirm_password: confirm.value
        }).then(function() {
            if (msg) msg.textContent = 'Password changed successfully.';
            toast('Password changed successfully.', 'success');
            current.value = '';
            next.value = '';
            confirm.value = '';
            if (button) button.disabled = false;
        }).catch(function(err) {
            if (msg) msg.textContent = 'Password change failed: ' + err.message;
            if (button) button.disabled = false;
        });
    }

    function renderSecurityPage() {
        var h = '<div class="security-page"><div class="card config-section"><div class="config-section-title">' + escapeHtml(tr('Security')) + '</div>' +
            '<p class="form-help">' + escapeHtml(tr('Change the WebGUI password. Password must contain at least 8 characters.')) + '</p>' +
            '<div class="config-password-grid">' +
            '<div class="form-group"><label class="form-label" for="sec-current-password">' + escapeHtml(tr('Current password')) + '</label>' +
            '<input id="sec-current-password" class="form-input" type="password" autocomplete="current-password"></div>' +
            '<div class="form-group"><label class="form-label" for="sec-new-password">' + escapeHtml(tr('New password')) + '</label>' +
            '<input id="sec-new-password" class="form-input" type="password" minlength="8" autocomplete="new-password"></div>' +
            '<div class="form-group"><label class="form-label" for="sec-confirm-password">' + escapeHtml(tr('Confirm password')) + '</label>' +
            '<input id="sec-confirm-password" class="form-input" type="password" minlength="8" autocomplete="new-password"></div>' +
            '</div>' +
            '<p id="security-message" class="security-message"></p>' +
            '<div class="config-actions"><button class="btn btn-primary" data-action="security-change-password">' + escapeHtml(tr('Change password')) + '</button></div>' +
            '</div></div>';
        return Promise.resolve(h);
    }

    function saveConfig() {
        var inputs = document.querySelectorAll('#content input[data-key]');
        var changes = [];
        inputs.forEach(function(inp) {
            if (inp.dataset.bool === '1') {
                if (inp.checked !== inp.defaultChecked) {
                    changes.push(API.put('/config', { key: inp.dataset.key, value: inp.checked ? '1' : '0' }));
                }
            } else if (inp.value !== inp.defaultValue) {
                changes.push(API.put('/config', { key: inp.dataset.key, value: inp.value }));
            }
        });
        if (!changes.length) {
            toast('No configuration changes to save', 'info');
            return;
        }
        var button = document.getElementById('save-config-btn');
        if (button) {
            button.disabled = true;
            button.textContent = 'Saving...';
        }
        Promise.all(changes).then(function() {
            toast('Saved ' + changes.length + ' configuration change(s)', 'success');
            Router.navigate('config');
        }).catch(function(err) {
            toast('Configuration save failed: ' + err.message, 'error');
            if (button) {
                button.disabled = false;
                button.textContent = 'Save Changes';
            }
        });
    }

    // ----- Alerts -----
    function renderAlerts() {
        return '<div class="card"><div class="card-header"><span class="card-title">Test Alerts</span></div>' +
            '<div class="form-group"><label class="form-label">Type</label><select class="form-input" id="alert_type"><option value="scan">Scan</option><option value="digest">Digest</option></select></div>' +
            '<div class="form-group"><label class="form-label">Channel</label><select class="form-input" id="alert_chan"><option value="email">Email</option><option value="telegram">Telegram</option></select></div>' +
            '<button class="btn btn-primary" data-action="send-alert">Send Test Alert</button></div>';
    }

    function sendAlert() {
        var type = document.getElementById('alert_type').value;
        var chan = document.getElementById('alert_chan').value;
        var button = document.querySelector('[data-action="send-alert"]');
        if (button) {
            button.disabled = true;
            button.textContent = 'Sending...';
        }
        API.post('/test-alert', { type: type, channel: chan }).then(function(data) {
            var output = data.stderr || data.stdout || '';
            toast(output || 'Alert sent successfully', 'success');
        }).catch(function(err) {
            toast('Alert failed: ' + err.message, 'error', 8000);
        }).finally(function() {
            if (button) {
                button.disabled = false;
                button.textContent = 'Send Test Alert';
            }
        });
    }

    // ----- Logs -----
    function renderLogs() {
        return API.get('/logs?lines=200').then(function(data) {
            var logs = data.logs || [];
            var h = '<div class="card"><div class="card-header"><span class="card-title">Logs</span>' +
                '<button class="btn btn-ghost btn-sm" data-action="refresh">Refresh</button></div>';
            h += '<div class="form-help" style="margin-bottom:12px;">' +
                escapeHtml(data.path || 'event_log') + ' · ' + logs.length + ' ' + tr('entries') + '</div>';
            h += '<div style="max-height:60vh;overflow:auto;"><table style="width:100%;"><tbody>';
            if (!logs.length) {
                h += '<tr><td class="form-help">No log entries found.</td></tr>';
            }
            for (var i = 0; i < logs.length; i++) {
                h += '<tr><td style="font-family:monospace;font-size:12px;white-space:pre-wrap;">' + escapeHtml(logs[i]) + '</td></tr>';
            }
            h += '</tbody></table></div></div>';
            return h;
        });
    }

    // ----- Ignore -----
    function renderIgnore() {
        return API.get('/ignore').then(function(data) {
            var files = data.files || {};
            var h = '<div class="card"><div class="card-header"><span class="card-title">Ignore Lists</span></div><div class="tabs">';
            var first = true;
            for (var name in files) {
                h += '<div class="tab" data-action="ignore-tab" data-name="' + escapeHtml(name) + '">' + escapeHtml(name) + '</div>';
                first = false;
            }
            h += '</div>';
            for (var name in files) {
                var info = files[name];
                h += '<div id="ignore-' + name + '" style="display:' + (name === Object.keys(files)[0] ? 'block' : 'none') + ';">';
                h += '<p style="font-size:12px;color:var(--text-muted);">' + escapeHtml(info.description) + '</p>';
                h += '<textarea class="form-textarea" rows="10" style="width:100%;">' + info.lines.map(function(l) { return escapeHtml(l); }).join('\n') + '</textarea>';
                h += '<button class="btn btn-primary" data-action="save-ignore" data-name="' + escapeHtml(name) + '">' +
                    tr('Save ignore list') + '</button></div>';
            }
            h += '</div>';
            return h;
        });
    }

    function showIgnoreTab(name) {
        var tabs = document.querySelectorAll('[id^="ignore-"]');
        for (var i = 0; i < tabs.length; i++) tabs[i].style.display = 'none';
        document.getElementById('ignore-' + name).style.display = 'block';
    }

    function saveIgnore(name, button) {
        var section = document.getElementById('ignore-' + name);
        var textarea = section ? section.querySelector('textarea') : null;
        if (!textarea) return;
        button.disabled = true;
        API.put('/ignore', { filename: name, lines: textarea.value.split(/\r?\n/) }).then(function() {
            return API.get('/ignore');
        }).then(function() {
            Router.navigate('ignore');
            toast(tr('Ignore list saved'), 'success');
        }).catch(function(err) {
            toast(tr('Ignore list save failed: ') + err.message, 'error');
        }).finally(function() {
            button.disabled = false;
        });
    }

    // ----- Maintenance -----
    function renderMaintenance() {
        return '<div class="card"><div class="card-header"><span class="card-title">Maintenance</span></div>' +
            '<button class="btn btn-warning" data-action="run-maint">Run Maintenance</button> ' +
            '<button class="btn btn-danger" data-action="run-purge">Purge All Data</button></div>';
    }

    function runMaint() {
        API.post('/maintenance', {}).then(function() { toast('Maintenance complete', 'success'); });
    }
    function runPurge() {
        if (!confirm('Clear all logs, quarantine, and temp data?')) return;
        API.post('/purge', {}).then(function() { toast('Purge complete', 'success'); });
    }

    // ----- System Info -----
    function systemMetric(label, percent, detail) {
        var valid = typeof percent === 'number' && isFinite(percent);
        var value = valid ? Math.max(0, Math.min(100, percent)) : null;
        var level = value === null ? '' : value >= 85 ? ' danger' : value >= 60 ? ' warning' : '';
        var display = value === null ? tr('Unavailable') : Math.round(value) + '%';
        return '<div class="system-metric card"><div class="system-metric-heading"><span>' +
            escapeHtml(label) + '</span><strong>' + escapeHtml(display) + '</strong></div>' +
            '<div class="system-meter' + level + '" role="progressbar" aria-label="' + escapeHtml(label) +
            '" aria-valuemin="0" aria-valuemax="100"' +
            (value === null ? '' : ' aria-valuenow="' + Math.round(value) + '"') +
            '><div class="system-meter-fill" style="width:' + (value === null ? 0 : value) + '%"></div></div>' +
            '<div class="system-metric-detail">' + escapeHtml(detail) + '</div></div>';
    }

    function systemDetail(label, value) {
        return '<div class="system-detail"><dt>' + tr(label) + '</dt><dd>' +
            escapeHtml(value === null || value === undefined || value === '' ? tr('Unavailable') : String(value)) +
            '</dd></div>';
    }

    function renderSystemInfo() {
        return Promise.all([API.get('/system'), API.get('/system/usage').catch(function() {
            return null;
        })]).then(function(results) {
            var sys = results[0].system, usage = results[1];
            var memTotal = usage && usage.mem_total_mb > 0 ? usage.mem_total_mb : sys.mem_total_mb;
            var memAvailable = usage && usage.mem_total_mb > 0 ? usage.mem_available_mb : sys.mem_available_mb;
            var memValid = typeof memTotal === 'number' && memTotal > 0 &&
                typeof memAvailable === 'number' && memAvailable >= 0;
            var diskValid = typeof sys.disk_total_gb === 'number' && sys.disk_total_gb > 0 &&
                typeof sys.disk_free_gb === 'number' && sys.disk_free_gb >= 0;
            var memUsed = memValid ? Math.max(0, memTotal - memAvailable) : 0;
            var diskUsed = diskValid ? Math.max(0, sys.disk_total_gb - sys.disk_free_gb) : 0;
            var h = '<div class="system-page"><div class="card system-hero">' +
                '<div><span class="system-eyebrow">' + tr('Host overview') + '</span><h2>' +
                escapeHtml(sys.hostname || tr('Unavailable')) + '</h2><p>' +
                escapeHtml([sys.system, sys.release, sys.machine].filter(Boolean).join(' ') || tr('Unavailable')) +
                '</p></div><div class="system-health">' +
                '<span class="system-health-item ' + (sys.monitor_running ? 'is-online' : 'is-offline') + '">' +
                tr('Monitor') + ': ' + tr(sys.monitor_running ? 'ONLINE' : 'OFFLINE') + '</span>' +
                '<span class="system-health-item">' + tr('Active Scans') + ': ' +
                (Array.isArray(sys.active_scans) ? sys.active_scans.length : 0) + '</span></div></div>';
            h += '<h3 class="system-section-title">' + tr('System resources') + '</h3><div class="system-metrics">';
            h += systemMetric(tr('CPU'), usage && usage.cpu_percent,
                sys.cpu || tr('Unavailable'));
            h += systemMetric(tr('RAM'), memValid ? memUsed / memTotal * 100 : null,
                memValid ? formatMb(memUsed) + ' ' + tr('used') + ' ' + tr('of') + ' ' + formatMb(memTotal) +
                    ' · ' + formatMb(memAvailable) + ' ' + tr('available') : tr('Unavailable'));
            h += systemMetric(tr('Disk'), diskValid ? diskUsed / sys.disk_total_gb * 100 : null,
                diskValid ? diskUsed.toFixed(1) + ' GB ' + tr('used') + ' ' + tr('of') + ' ' +
                    sys.disk_total_gb + ' GB · ' + sys.disk_free_gb + ' GB ' + tr('free') : tr('Unavailable'));
            h += '</div><div class="system-panels"><div class="card"><div class="card-header"><span class="card-title">' +
                tr('Host and runtime') + '</span></div><dl class="system-details">';
            h += systemDetail('Hostname', sys.hostname);
            h += systemDetail('Operating system', [sys.system, sys.release].filter(Boolean).join(' '));
            h += systemDetail('Architecture', sys.machine);
            h += systemDetail('Processor', sys.cpu || sys.processor);
            h += systemDetail('CPU cores', sys.cpu_cores);
            h += systemDetail('Python version', sys.python_version);
            h += '</dl></div><div class="card"><div class="card-header"><span class="card-title">' +
                tr('System Information') + '</span></div><dl class="system-details">';
            h += systemDetail('Maldet Version', sys.version);
            h += systemDetail('Signature Set', sys.signature_version);
            h += systemDetail('ClamAV', (sys.clamav_version || tr('Unavailable')) +
                ' (' + (sys.clamav_status || tr('Unavailable')) + ')');
            h += systemDetail('Install path', sys.base_dir);
            h += systemDetail('Log directory', sys.log_dir);
            h += systemDetail('Maldet binary', sys.maldet_path);
            h += systemDetail('Installer path', sys.installer_path);
            h += systemDetail('Installer directory', sys.installer_directory);
            h += systemDetail('GUI privileges', sys.is_root ? tr('Root') : tr('Unprivileged'));
            h += systemDetail('Effective UID', sys.euid);
            h += systemDetail('Monitor PIDs', (sys.monitor_pids || []).join(', '));
            h += '</dl></div></div><div class="card"><div class="card-header"><span class="card-title">' +
                tr('Binary Detection') + '</span></div><div class="system-binaries">';
            var binaries = sys.binaries || {};
            var names = Object.keys(binaries).sort();
            if (!names.length) h += '<p class="form-help">' + tr('No binaries reported') + '</p>';
            names.forEach(function(name) {
                var path = binaries[name];
                h += '<div class="system-binary"><div><strong>' + escapeHtml(name) +
                    '</strong><span>' + escapeHtml(path || tr('not found')) + '</span></div>' +
                    '<span class="badge ' + (path ? 'bg-success' : 'bg-danger') + '">' +
                    tr(path ? 'Found' : 'Missing') + '</span></div>';
            });
            h += '</div></div></div>';
            return h;
        });
    }

    // ----- About -----
    function renderAbout() {
        return '<div class="about-html-page">' +
            '<header class="about-html-header"><div class="about-logo-area"><h1>Linux Malware Detect</h1><span>Maldet</span></div>' +
            '<div class="about-actions" aria-label="Ferramentas e Idioma">' +
            '<button class="about-action" title="Idioma" data-action="about-language">🌐</button>' +
            '<button class="about-action" title="Atualizar" data-action="about-refresh">🔄</button>' +
            '<button class="about-action" title="Configurações" data-action="about-settings">⚙️</button></div></header>' +
            '<main>' +
            '<section class="about-html-card"><h2>Sobre o Maldet / About Maldet</h2>' +
            '<div class="about-lang-section"><div class="about-lang-title">Português (Brasil)</div>' +
            '<p>Uma camada prática de detecção de malware para servidores Linux, com varredura nativa, quarentena, monitoramento em tempo real e WebGUI.</p>' +
            '<p>O Maldet analisa arquivos em busca de assinaturas conhecidas e indicadores de comprometimento. Você pode iniciar scans completos ou recentes, acompanhar o progresso, revisar detalhes das infecções e restaurar arquivos da quarentena.</p></div>' +
            '<hr class="about-divider"><div class="about-lang-section"><div class="about-lang-title">English</div>' +
            '<p>A practical malware detection layer for Linux servers, with native scanning, quarantine, real-time monitoring, and a WebGUI.</p>' +
            '<p>Maldet scans files for known signatures and indicators of compromise. You can start full or recent scans, follow progress, review infection details, and restore quarantined files.</p></div></section>' +
            '<section class="about-html-card"><h2>Recursos / Key Features</h2><div class="about-feature-grid">' +
            '<div><div class="about-lang-title">Português (Brasil)</div><ul><li>Engine nativo do Maldet</li><li>Quarentena e detalhes por arquivo</li><li>Monitoramento inotify por usuário</li><li>Alertas e relatórios</li><li>Assinaturas atualizáveis</li></ul></div>' +
            '<div><div class="about-lang-title">English</div><ul><li>Maldet native engine</li><li>Quarantine with per-file details</li><li>Per-user inotify monitoring</li><li>Alerts and reports</li><li>Updatable signatures</li></ul></div></div></section>' +
            '<section class="about-html-card"><h2>Desenvolvedor / Developer</h2>' +
            '<p><strong>Bithostel</strong></p>' +
            '<ul><li>Website: <a href="https://bithostel.com.br" target="_blank" rel="noopener noreferrer">bithostel.com.br</a></li>' +
            '<li>E-mail: <a href="mailto:hostmaster@bithostel.com.br">hostmaster@bithostel.com.br</a></li></ul></section>' +
            '</main><footer class="about-html-footer"><p><strong>Uso responsável / Responsible use:</strong><br>Use o Maldet em sistemas que você administra e mantenha as assinaturas atualizadas.<br><em>Use Maldet on systems you administer and keep signatures up to date.</em></p></footer></div>';
    }

    // ----- Register Routes -----
    Router.register('dashboard', renderDashboard);
    Router.register('scanner', renderScanner);
    Router.register('scan-management', renderScanManagement);
    Router.register('quarantine', renderQuarantine);
    Router.register('reports', renderReports);
    Router.register('monitoring', renderMonitoring);
    Router.register('schedules', renderSchedules);
    Router.register('updates', renderUpdates);
    Router.register('security', renderSecurityPage);
    Router.register('config', renderConfig);
    Router.register('alerts', renderAlerts);
    Router.register('logs', renderLogs);
    Router.register('ignore', renderIgnore);
    Router.register('maintenance', renderMaintenance);
    Router.register('system', renderSystemInfo);
    Router.register('about', renderAbout);

    // ----- Initialize -----
    document.addEventListener('DOMContentLoaded', function() {
        window.__maldet_booted = true;
        // Resume an in-flight reboot or WebGUI-reload countdown after a page
        // reload so the timer does not restart from the top.
        resumeRebootCountdown();
        resumeGuiReloadCountdown();
        API.get('/auth/status').then(function(status) {
            if (status.authenticated) {
                Router.init();
                initStatusIndicator();
            } else {
                showAuthScreen(status.setup_required);
            }
        }).catch(function() { showAuthScreen(true); });
    });

    // ----- Global exposure (backward compatibility) -----
    // Buttons now use delegated data-action clicks (see Router.init), which
    // work regardless of scope/CSP.  These exports are kept so any cached
    // HTML or console calls to fn() keep working.
    window.startScan = startScan;
    window.stopScan = stopScan;
    window.scanAction = scanAction;
    window.monitorStart = monitorStart;
    window.monitorStop = monitorStop;
    window.runMaint = runMaint;
    window.runPurge = runPurge;
    window.saveConfig = saveConfig;
    window.sendAlert = sendAlert;
    window.showIgnoreTab = showIgnoreTab;
    window.updateVer = updateVer;
    window.updateSigs = updateSigs;
})();
